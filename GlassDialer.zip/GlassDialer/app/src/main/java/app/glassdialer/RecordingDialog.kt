package app.glassdialer

import android.media.MediaPlayer
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import app.glassdialer.call.Recordings
import kotlinx.coroutines.delay

/** Plays a saved call recording and lets the user delete it or copy it to Downloads. */
@Composable
fun RecordingDialog(rec: Recordings.Rec, title: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableIntStateOf(0) }
    var dur by remember { mutableIntStateOf(0) }
    val player = remember {
        try {
            MediaPlayer().apply {
                setDataSource(rec.file.absolutePath)
                prepare()
                setOnCompletionListener { playing = false; pos = 0 }
            }
        } catch (_: Throwable) {
            null
        }
    }
    LaunchedEffect(player) { dur = player?.duration ?: 0 }
    LaunchedEffect(playing) {
        while (playing) {
            pos = player?.currentPosition ?: 0
            delay(150)
        }
    }
    DisposableEffect(Unit) { onDispose { try { player?.release() } catch (_: Throwable) { } } }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(c.surfaceHigh).padding(22.dp)
        ) {
            Text(stringResource(R.string.rec_title), color = c.sub, fontSize = 13.sp)
            Text(
                title, color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(fmtDate(ctx, rec.startMs), color = c.sub, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(52.dp).clip(CircleShape).background(c.accent).tap(enabled = player != null) {
                        val p = player ?: return@tap
                        if (playing) {
                            p.pause()
                            playing = false
                        } else {
                            p.start()
                            playing = true
                        }
                    },
                    contentAlignment = Alignment.Center
                ) { Icon(if (playing) Ic.pause else Ic.play, null, Modifier.size(30.dp), tint = Color.White) }
                Spacer(Modifier.size(12.dp))
                Column(Modifier.weight(1f)) {
                    Slider(
                        value = pos.toFloat().coerceAtMost(dur.toFloat().coerceAtLeast(1f)),
                        onValueChange = { pos = it.toInt(); player?.seekTo(pos) },
                        valueRange = 0f..dur.toFloat().coerceAtLeast(1f),
                        colors = SliderDefaults.colors(
                            thumbColor = c.accent,
                            activeTrackColor = c.accent,
                            inactiveTrackColor = c.sub.copy(alpha = 0.3f)
                        )
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(fmtTime(pos / 1000L), color = c.sub, fontSize = 12.sp)
                        Text(fmtTime(dur / 1000L), color = c.sub, fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.rec_delete), color = c.danger, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.tap { Recordings.delete(rec); onDismiss() }.padding(vertical = 10.dp, horizontal = 4.dp)
                )
                if (Build.VERSION.SDK_INT >= 29) {
                    Text(
                        stringResource(R.string.rec_save), color = c.accent, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.tap {
                            val ok = Recordings.saveToDownloads(ctx, rec)
                            Toast.makeText(ctx, if (ok) R.string.rec_saved else R.string.rec_save_failed, Toast.LENGTH_SHORT).show()
                        }.padding(vertical = 10.dp, horizontal = 4.dp)
                    )
                }
            }
        }
    }
}

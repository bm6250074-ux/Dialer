package app.glassdialer.call

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telecom.Call
import android.telecom.CallAudioState

class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            ACTION_DECLINE -> {
                CallManager.calls.value.firstOrNull { it.state == Call.STATE_RINGING }
                    ?.let { CallManager.reject(it.call) }
                Notifs.cancel(ctx)
            }
            // Answering from the notification keeps the user in whatever app they are using.
            ACTION_ANSWER -> {
                CallManager.calls.value.firstOrNull { it.state == Call.STATE_RINGING }
                    ?.let { CallManager.answer(it.call) }
                Notifs.cancel(ctx)
            }
            ACTION_HANGUP -> {
                CallManager.calls.value.firstOrNull { it.state != Call.STATE_RINGING }
                    ?.let { CallManager.hangup(it.call) }
            }
            ACTION_MUTE -> CallManager.setMuted(!CallManager.muted.value)
            ACTION_SPEAKER -> CallManager.setRoute(
                if (CallManager.route.value == CallAudioState.ROUTE_SPEAKER) CallAudioState.ROUTE_WIRED_OR_EARPIECE
                else CallAudioState.ROUTE_SPEAKER
            )
        }
    }

    companion object {
        const val ACTION_DECLINE = "app.glassdialer.DECLINE"
        const val ACTION_ANSWER = "app.glassdialer.ANSWER"
        const val ACTION_HANGUP = "app.glassdialer.HANGUP"
        const val ACTION_MUTE = "app.glassdialer.MUTE"
        const val ACTION_SPEAKER = "app.glassdialer.SPEAKER"
    }
}

package app.glassdialer

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.os.LocaleListCompat

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class GlassStyle { SOLID, BLUR, LIQUID }
enum class AppBg { SOLID, AURORA, IMAGE }
enum class CallBg { WALLPAPER, PHOTO, AURORA, SOLID }
enum class KeyStyle { PLAIN, CIRCLE }
enum class Accent(val argb: Long) {
    GREEN(0xFF22C55E), BLUE(0xFF3B82F6), PURPLE(0xFF8B5CF6), ORANGE(0xFFF97316),
    PINK(0xFFEC4899), TEAL(0xFF14B8A6), RED(0xFFEF4444), DYNAMIC(0xFF22C55E)
}

object Prefs {
    private var sp: SharedPreferences? = null
    private var notes: SharedPreferences? = null

    var themeMode by mutableStateOf(ThemeMode.SYSTEM)
        private set
    var glass by mutableStateOf(GlassStyle.SOLID)
        private set
    var accent by mutableStateOf(Accent.GREEN)
        private set
    var amoled by mutableStateOf(true)
        private set
    var appBg by mutableStateOf(AppBg.SOLID)
        private set
    var bgImage by mutableStateOf("")
        private set
    var bgBlur by mutableStateOf(40)
        private set
    var bgDim by mutableStateOf(25)
    var liquid by mutableStateOf(60)
    var lockPrompted by mutableStateOf(false)
        private set
    var callBg by mutableStateOf(CallBg.WALLPAPER)
        private set
    var callBlur by mutableStateOf(70)
        private set
    var callDim by mutableStateOf(35)
        private set
    var textScale by mutableStateOf(100)
        private set
    var keyStyle by mutableStateOf(KeyStyle.PLAIN)
        private set
    var showLetters by mutableStateOf(true)
        private set
    var showAvatar by mutableStateOf(true)
        private set
    var motion by mutableStateOf(true)
        private set
    var tones by mutableStateOf(true)
        private set
    var haptics by mutableStateOf(true)
        private set
    var defaultSim by mutableStateOf(-1)
        private set
    var lang by mutableStateOf("")
        private set

    private inline fun <reified T : Enum<T>> readEnum(p: SharedPreferences, key: String, def: T): T =
        runCatching { enumValueOf<T>(p.getString(key, def.name) ?: def.name) }.getOrDefault(def)

    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
        sp = p
        notes = ctx.applicationContext.getSharedPreferences("notes", Context.MODE_PRIVATE)
        themeMode = readEnum(p, "theme", ThemeMode.SYSTEM)
        glass = when (p.getString("glass", "SOLID")) {
            "BLUR", "GLASS", "FROSTED" -> GlassStyle.BLUR
            "LIQUID" -> GlassStyle.LIQUID
            else -> GlassStyle.SOLID
        }
        accent = readEnum(p, "accent", Accent.GREEN)
        amoled = p.getBoolean("amoled", true)
        appBg = readEnum(p, "appBg", AppBg.SOLID)
        bgImage = p.getString("bgImage", "") ?: ""
        bgBlur = p.getInt("bgBlur", 40)
        bgDim = p.getInt("bgDim", 25)
        liquid = p.getInt("liquid", 60)
        lockPrompted = p.getBoolean("lockPrompted", false)
        callBg = readEnum(p, "callBg", CallBg.WALLPAPER)
        callBlur = p.getInt("callBlur", 70)
        callDim = p.getInt("callDim", 35)
        textScale = p.getInt("textScale", 100)
        keyStyle = readEnum(p, "keyStyle", KeyStyle.PLAIN)
        showLetters = p.getBoolean("showLetters", true)
        showAvatar = p.getBoolean("showAvatar", true)
        motion = p.getBoolean("motion", true)
        tones = p.getBoolean("tones", true)
        haptics = p.getBoolean("haptics", true)
        defaultSim = p.getInt("defaultSim", -1)
        lang = p.getString("lang", "") ?: ""
    }

    private fun putS(k: String, v: String) { sp?.edit()?.putString(k, v)?.apply() }
    private fun putI(k: String, v: Int) { sp?.edit()?.putInt(k, v)?.apply() }
    private fun putB(k: String, v: Boolean) { sp?.edit()?.putBoolean(k, v)?.apply() }

    fun updateThemeMode(v: ThemeMode) { themeMode = v; putS("theme", v.name) }
    fun updateGlass(v: GlassStyle) { glass = v; putS("glass", v.name) }
    fun updateAccent(v: Accent) { accent = v; putS("accent", v.name) }
    fun updateAmoled(v: Boolean) { amoled = v; putB("amoled", v) }
    fun updateAppBg(v: AppBg) { appBg = v; putS("appBg", v.name) }
    fun updateBgImage(v: String) { bgImage = v; putS("bgImage", v) }
    fun updateBgBlur(v: Int) { bgBlur = v; putI("bgBlur", v) }
    fun updateBgDim(v: Int) { bgDim = v; putI("bgDim", v) }
    fun updateLiquid(v: Int) { liquid = v; putI("liquid", v) }
    fun updateLockPrompted(v: Boolean) { lockPrompted = v; putB("lockPrompted", v) }
    fun updateCallBg(v: CallBg) { callBg = v; putS("callBg", v.name) }
    fun updateCallBlur(v: Int) { callBlur = v; putI("callBlur", v) }
    fun updateCallDim(v: Int) { callDim = v; putI("callDim", v) }
    fun updateTextScale(v: Int) { textScale = v; putI("textScale", v) }
    fun updateKeyStyle(v: KeyStyle) { keyStyle = v; putS("keyStyle", v.name) }
    fun updateShowLetters(v: Boolean) { showLetters = v; putB("showLetters", v) }
    fun updateShowAvatar(v: Boolean) { showAvatar = v; putB("showAvatar", v) }
    fun updateMotion(v: Boolean) { motion = v; putB("motion", v) }
    fun updateTones(v: Boolean) { tones = v; putB("tones", v) }
    fun updateHaptics(v: Boolean) { haptics = v; putB("haptics", v) }
    fun updateDefaultSim(v: Int) { defaultSim = v; putI("defaultSim", v) }

    fun updateLang(tag: String) {
        lang = tag
        putS("lang", tag)
        AppCompatDelegate.setApplicationLocales(
            if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList()
            else LocaleListCompat.forLanguageTags(tag)
        )
    }

    fun note(number: String): String {
        val k = Repo.norm(number)
        return if (k.isEmpty()) "" else (notes?.getString(k, "") ?: "")
    }

    fun updateNote(number: String, text: String) {
        val k = Repo.norm(number)
        if (k.isEmpty()) return
        val e = notes?.edit() ?: return
        if (text.isBlank()) e.remove(k) else e.putString(k, text)
        e.apply()
    }

    fun saveCrash(s: String) { sp?.edit()?.putString("crash", s)?.commit() }
    fun lastCrash(): String = sp?.getString("crash", "") ?: ""
    fun clearCrash() { sp?.edit()?.remove("crash")?.apply() }
}

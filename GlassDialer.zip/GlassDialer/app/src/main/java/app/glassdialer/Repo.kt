package app.glassdialer

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import android.net.Uri
import android.provider.CallLog
import android.provider.CallLog.Calls as Calls
import android.provider.ContactsContract.CommonDataKinds.Phone as Phone
import android.provider.ContactsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class CallEntry(
    val id: Long,
    val number: String,
    val name: String?,
    val photo: String?,
    val type: Int,
    val date: Long,
    val duration: Long,
    val count: Int = 1
)

data class ContactEntry(val id: Long, val name: String, val number: String, val photo: String?)

object Repo {
    fun norm(n: String): String = n.filter { it.isDigit() }.takeLast(9)

    suspend fun contacts(ctx: Context): List<ContactEntry> = withContext(Dispatchers.IO) {
        val out = ArrayList<ContactEntry>()
        if (!ctx.has(Manifest.permission.READ_CONTACTS)) return@withContext out
        val seen = HashSet<String>()
        try {
            ctx.contentResolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER, Phone.PHOTO_THUMBNAIL_URI),
                null, null,
                Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val name = c.getString(1) ?: continue
                    val num = c.getString(2) ?: continue
                    if (!seen.add(id.toString() + ":" + norm(num))) continue
                    out.add(ContactEntry(id, name, num, c.getString(3)))
                }
            }
        } catch (_: Throwable) {
        }
        out
    }

    /** Deletes a whole contact (needs WRITE_CONTACTS). */
    suspend fun deleteContact(ctx: Context, contactId: Long): Boolean = withContext(Dispatchers.IO) {
        try {
            ctx.contentResolver.delete(
                android.content.ContentUris.withAppendedId(android.provider.ContactsContract.Contacts.CONTENT_URI, contactId),
                null, null
            ) > 0
        } catch (_: Throwable) {
            false
        }
    }

    suspend fun calls(ctx: Context, byNum: Map<String, ContactEntry>): List<CallEntry> = withContext(Dispatchers.IO) {
        val raw = ArrayList<CallEntry>()
        if (!ctx.has(Manifest.permission.READ_CALL_LOG)) return@withContext raw
        try {
            ctx.contentResolver.query(
                Calls.CONTENT_URI,
                arrayOf(Calls._ID, Calls.NUMBER, Calls.CACHED_NAME, Calls.TYPE, Calls.DATE, Calls.DURATION),
                null, null, Calls.DATE + " DESC"
            )?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 400) {
                    var num = c.getString(1) ?: ""
                    if (num == "-1" || num == "-2") num = ""
                    val hit = byNum[norm(num)]
                    val cached = c.getString(2)
                    raw.add(
                        CallEntry(
                            id = c.getLong(0),
                            number = num,
                            name = if (!cached.isNullOrBlank()) cached else hit?.name,
                            photo = hit?.photo,
                            type = c.getInt(3),
                            date = c.getLong(4),
                            duration = c.getLong(5)
                        )
                    )
                    n++
                }
            }
        } catch (_: Throwable) {
        }
        val out = ArrayList<CallEntry>()
        for (e in raw) {
            val last = out.lastOrNull()
            if (last != null && last.number == e.number && last.type == e.type) {
                out[out.size - 1] = last.copy(count = last.count + 1)
            } else out.add(e)
        }
        out
    }

    suspend fun lookup(ctx: Context, number: String): Pair<String?, String?> = withContext(Dispatchers.IO) {
        var result: Pair<String?, String?> = Pair(null, null)
        if (number.isNotBlank() && ctx.has(Manifest.permission.READ_CONTACTS)) {
            try {
                val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
                ctx.contentResolver.query(
                    uri,
                    arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME, ContactsContract.PhoneLookup.PHOTO_THUMBNAIL_URI),
                    null, null, null
                )?.use { c ->
                    if (c.moveToFirst()) result = Pair(c.getString(0), c.getString(1))
                }
            } catch (_: Throwable) {
            }
        }
        result
    }

    fun deleteNumber(ctx: Context, number: String) {
        try {
            ctx.contentResolver.delete(CallLog.Calls.CONTENT_URI, CallLog.Calls.NUMBER + "=?", arrayOf(number))
        } catch (_: Throwable) {
        }
    }

    private fun fileBase(ctx: Context, uri: Uri): String {
        var n = ""
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) n = it.getString(0) ?: ""
            }
        } catch (_: Throwable) {
        }
        return n.substringBeforeLast('.').trim()
    }

    private fun photoBytes(ctx: Context, uri: Uri): ByteArray? {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 1000 || bounds.outHeight / (sample * 2) >= 1000) sample *= 2
        val o = BitmapFactory.Options()
        o.inSampleSize = sample
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return null
        val scale = minOf(1f, 720f / maxOf(bmp.width, bmp.height).toFloat())
        val out = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                bmp, (bmp.width * scale).toInt().coerceAtLeast(1), (bmp.height * scale).toInt().coerceAtLeast(1), true
            )
        } else bmp
        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 90, bos)
        return bos.toByteArray()
    }

    private fun writePhoto(ctx: Context, contactId: Long, bytes: ByteArray): Boolean {
        val cr = ctx.contentResolver
        var rawId = -1L
        cr.query(
            ContactsContract.RawContacts.CONTENT_URI, arrayOf(ContactsContract.RawContacts._ID),
            ContactsContract.RawContacts.CONTACT_ID + "=?", arrayOf(contactId.toString()), null
        )?.use { if (it.moveToFirst()) rawId = it.getLong(0) }
        if (rawId < 0) return false
        val v = ContentValues()
        v.put(ContactsContract.Data.RAW_CONTACT_ID, rawId)
        v.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE)
        v.put(ContactsContract.CommonDataKinds.Photo.PHOTO, bytes)
        val where = ContactsContract.Data.RAW_CONTACT_ID + "=? AND " + ContactsContract.Data.MIMETYPE + "=?"
        val updated = cr.update(
            ContactsContract.Data.CONTENT_URI, v, where,
            arrayOf(rawId.toString(), ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE)
        )
        if (updated == 0) cr.insert(ContactsContract.Data.CONTENT_URI, v)
        return true
    }

    /**
     * Saves each picked image as the photo of the contact it is named after
     * (file name = contact name, or = phone number). Returns how many were saved, or -1 without permission.
     */
    suspend fun importPhotos(ctx: Context, uris: List<Uri>): Int {
        if (!ctx.has(Manifest.permission.WRITE_CONTACTS) || !ctx.has(Manifest.permission.READ_CONTACTS)) return -1
        val all = contacts(ctx)
        return withContext(Dispatchers.IO) {
            var done = 0
            for (u in uris) {
                try {
                    val base = fileBase(ctx, u)
                    if (base.isEmpty()) continue
                    val digits = base.filter { it.isDigit() }
                    val hit = all.firstOrNull { it.name.equals(base, ignoreCase = true) }
                        ?: (if (digits.length >= 6) all.firstOrNull { norm(it.number) == norm(digits) } else null)
                        ?: continue
                    val bytes = photoBytes(ctx, u) ?: continue
                    if (writePhoto(ctx, hit.id, bytes)) done++
                } catch (_: Throwable) {
                }
            }
            done
        }
    }
}

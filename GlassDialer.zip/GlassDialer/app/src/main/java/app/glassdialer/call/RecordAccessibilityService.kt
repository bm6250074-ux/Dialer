package app.glassdialer.call

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

/**
 * Companion service for call recording. It does not read the screen (no window content, no event handling):
 * having it enabled is what lets the system keep delivering microphone audio to the recorder while a call is
 * in progress on many devices. Call start/end and the number come from the dialer's InCallService.
 */
class RecordAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    companion object {
        fun isEnabled(ctx: Context): Boolean {
            val list = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?: return false
            val me = ComponentName(ctx, RecordAccessibilityService::class.java)
            return list.split(':').any { ComponentName.unflattenFromString(it) == me }
        }

        fun openSettings(ctx: Context) {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Throwable) {
            }
        }
    }
}

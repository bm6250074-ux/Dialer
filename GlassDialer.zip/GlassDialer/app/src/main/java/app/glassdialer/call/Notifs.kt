package app.glassdialer.call

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import app.glassdialer.InCallActivity
import app.glassdialer.R

object Notifs {
    private const val CH = "incoming_calls"
    private const val ID = 4101

    fun showIncoming(ctx: Context, name: String?, number: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CH, ctx.getString(R.string.incoming_call), NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            ctx, 1, Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), flags
        )
        // Broadcast (not an activity): answering must not pull the user out of the app they are in.
        val answer = PendingIntent.getBroadcast(
            ctx, 2, Intent(ctx, CallActionReceiver::class.java).setAction(CallActionReceiver.ACTION_ANSWER), flags
        )
        val decline = PendingIntent.getBroadcast(
            ctx, 3, Intent(ctx, CallActionReceiver::class.java).setAction(CallActionReceiver.ACTION_DECLINE), flags
        )
        val title = if (!name.isNullOrBlank()) name else if (number.isNotBlank()) number else ctx.getString(R.string.unknown)
        val sub = if (!name.isNullOrBlank() && number.isNotBlank()) number else ctx.getString(R.string.incoming_sub)
        // Custom card: name on top, subtitle below, round decline / answer buttons on the right.
        val card = RemoteViews(ctx.packageName, R.layout.notif_incoming).apply {
            setTextViewText(R.id.n_title, title)
            setTextViewText(R.id.n_sub, sub)
            setOnClickPendingIntent(R.id.n_decline, decline)
            setOnClickPendingIntent(R.id.n_answer, answer)
        }
        val n = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_call)
            .setContentTitle(title)
            .setContentText(sub)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setTimeoutAfter(70_000)
            .setFullScreenIntent(open, true)
            .setContentIntent(open)
            .setCustomContentView(card)
            .setCustomHeadsUpContentView(card)
            .setCustomBigContentView(card)
            .build()
        try {
            nm.notify(ID, n)
        } catch (_: SecurityException) {
        }
    }

    private const val CH_ONGOING = "ongoing_calls"
    private const val ID_ONGOING = 4102

    fun showOngoing(ctx: Context, title: String, connectMs: Long, muted: Boolean, speaker: Boolean) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CH_ONGOING, ctx.getString(R.string.ongoing_call), NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            ctx, 4,
            Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags
        )
        fun action(code: Int, act: String) = PendingIntent.getBroadcast(
            ctx, code, Intent(ctx, CallActionReceiver::class.java).setAction(act), flags
        )
        val b = NotificationCompat.Builder(ctx, CH_ONGOING)
            .setSmallIcon(R.drawable.ic_call)
            .setContentTitle(title)
            .setContentText(ctx.getString(R.string.ongoing_call))
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, ctx.getString(if (muted) R.string.unmute else R.string.mute), action(6, CallActionReceiver.ACTION_MUTE))
            .addAction(0, ctx.getString(if (speaker) R.string.speaker_off else R.string.speaker), action(7, CallActionReceiver.ACTION_SPEAKER))
            .addAction(0, ctx.getString(R.string.end_call), action(5, CallActionReceiver.ACTION_HANGUP))
        if (connectMs > 0) b.setWhen(connectMs).setShowWhen(true).setUsesChronometer(true)
        try {
            nm.notify(ID_ONGOING, b.build())
        } catch (_: SecurityException) {
        }
    }

    fun cancelOngoing(ctx: Context) {
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID_ONGOING)
    }

    fun cancel(ctx: Context) {
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID)
    }
}

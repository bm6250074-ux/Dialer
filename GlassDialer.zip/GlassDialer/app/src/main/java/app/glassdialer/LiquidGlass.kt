package app.glassdialer

import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Shader
import androidx.annotation.RequiresApi
import androidx.compose.ui.graphics.asComposeRenderEffect

/**
 * "Liquid Glass" panel material (Android 13+, AGSL):
 *  - the backdrop is lightly diffused (readability, like Apple's refined glass),
 *  - the rim acts as a convex lens: content near the edge is bent / compressed inward, with a hint of
 *    chromatic dispersion,
 *  - a thin specular rim light from the top-left, a faint internal reflection on the opposite side and a
 *    soft inner glow, plus a gentle vibrancy / brightness lift.
 * [strength] (0..1) scales the whole effect (the settings slider).
 */
@RequiresApi(33)
internal class LiquidShader {
    private val shader = RuntimeShader(SRC)

    fun effect(
        left: Float, top: Float, right: Float, bottom: Float,
        radius: Float, density: Float, strength: Float, dark: Boolean
    ): androidx.compose.ui.graphics.RenderEffect {
        val s = strength.coerceIn(0f, 1f)
        val bezel = (10f + 16f * s) * density
        shader.setFloatUniform("rect", left, top, right, bottom)
        shader.setFloatUniform("radius", radius)
        shader.setFloatUniform("bezel", bezel)
        shader.setFloatUniform("strength", s)
        shader.setFloatUniform("dark", if (dark) 1f else 0f)
        shader.setFloatUniform("px", density)
        val lens = RenderEffect.createRuntimeShaderEffect(shader, "content")
        val diffuse = (6f + 10f * (1f - s)) * density / 2f
        val blur = RenderEffect.createBlurEffect(diffuse, diffuse, Shader.TileMode.CLAMP)
        return RenderEffect.createChainEffect(lens, blur).asComposeRenderEffect()
    }

    companion object {
        private const val SRC = """
uniform shader content;
uniform float4 rect;
uniform float radius;
uniform float bezel;
uniform float strength;
uniform float dark;
uniform float px;

float sdf(float2 p) {
    float2 c = (rect.xy + rect.zw) * 0.5;
    float2 hs = (rect.zw - rect.xy) * 0.5;
    float2 q = abs(p - c) - hs + radius;
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - radius;
}

half4 main(float2 fc) {
    float d = sdf(fc);
    if (d > 0.0) {
        return half4(0.0);
    }
    float2 g = float2(
        sdf(fc + float2(1.0, 0.0)) - sdf(fc - float2(1.0, 0.0)),
        sdf(fc + float2(0.0, 1.0)) - sdf(fc - float2(0.0, 1.0))
    );
    float2 n = g / max(length(g), 0.0001);

    float depth = clamp(-d / bezel, 0.0, 1.0);
    float edge = 1.0 - depth;
    // convex lens: strongest bend at the rim, none in the middle
    float bend = pow(edge, 2.2);
    float mag = bend * bezel * (0.35 + 0.65 * strength);
    float2 off = n * mag;

    half4 cr = content.eval(fc - off * 1.07);
    half4 cg = content.eval(fc - off);
    half4 cb = content.eval(fc - off * 0.93);
    half3 col = half3(cr.r, cg.g, cb.b);

    // vibrancy + lift
    half l = dot(col, half3(0.299, 0.587, 0.114));
    col = mix(half3(l), col, 1.0 + 0.30 * strength);
    col += half3(0.03 * strength);

    // clear glass body tint
    float tint = mix(0.17, 0.055, dark);
    col = mix(col, half3(1.0), tint);

    // lighting: light from the top-left
    float2 L = normalize(float2(-0.55, -0.85));
    float facing = dot(n, L);
    float rim = exp(-(-d) / (1.5 * px));
    float spec = rim * (0.16 + 0.84 * max(facing, 0.0));
    float back = rim * 0.38 * max(-facing, 0.0);
    col += half3((spec * 0.85 + back) * (0.45 + 0.55 * strength));

    float glow = exp(-(-d) / (bezel * 0.6)) * max(facing, 0.0);
    col += half3(glow * 0.12 * strength);

    // faint shading on the side away from the light
    col *= 1.0 - 0.10 * edge * edge * max(-facing, 0.0) * strength;

    return half4(clamp(col, 0.0, 1.0), 1.0);
}
"""
    }
}

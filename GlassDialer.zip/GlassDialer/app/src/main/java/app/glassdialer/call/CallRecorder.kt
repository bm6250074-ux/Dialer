package app.glassdialer.call

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Entry point for call recording. The actual capture lives in [CallRecordService]. */
object CallRecorder {
    data class State(val active: Boolean = false, val startMs: Long = 0L)

    internal val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state

    @Volatile
    internal var service: CallRecordService? = null

    fun start(ctx: Context, label: String) {
        if (_state.value.active) return
        try {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, CallRecordService::class.java)
                    .setAction(CallRecordService.ACTION_START)
                    .putExtra(CallRecordService.EXTRA_LABEL, label)
            )
        } catch (_: Throwable) {
            CallRecordService.toast(ctx, app.glassdialer.R.string.record_failed)
        }
    }

    /** Stops and saves the recording (no-op when nothing is being recorded). */
    fun stop() {
        service?.finishRecording()
    }
}

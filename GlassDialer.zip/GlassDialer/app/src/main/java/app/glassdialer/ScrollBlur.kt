package app.glassdialer

import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize

/** 0..1 for how far a lazy list is scrolled away from its start (ramps up over the first ~60 px). */
fun LazyListState.scrollBlurStrength(): Float =
    if (firstVisibleItemIndex > 0) 1f else (firstVisibleItemScrollOffset / 24f).coerceIn(0f, 1f)

fun ScrollState.scrollBlurStrength(): Float = (value / 24f).coerceIn(0f, 1f)

/**
 * Progressive blur on the top edge of a scrolling area: content that scrolls up toward the header is blurred,
 * strongest at the edge and fading out downward. At scroll position 0 nothing extra is recorded or drawn.
 * Needs Android 12+ (RenderEffect); on older versions the content is simply drawn normally.
 */
fun Modifier.topScrollBlur(band: Dp, strength: () -> Float): Modifier = composed {
    val sourceLayer = rememberGraphicsLayer()
    val softLayer = rememberGraphicsLayer()
    val strongLayer = rememberGraphicsLayer()
    val veilLayer = rememberGraphicsLayer()
    val backdrop = LocalBackdrop.current
    val pos = remember { mutableStateOf(Offset.Zero) }
    this
        .onGloballyPositioned { pos.value = it.positionInRoot() }
        .drawWithContent {
            val s = strength().coerceIn(0f, 1f)
            if (s <= 0.01f || Build.VERSION.SDK_INT < 31 || backdrop == null) {
                drawContent()
            } else {
                sourceLayer.record { this@drawWithContent.drawContent() }
                drawLayer(sourceLayer)
                val w = size.width.toInt()
                val h = (band.toPx()).toInt().coerceAtMost(size.height.toInt())
                if (w > 0 && h > 0) {
                    val p = pos.value
                    // opaque base (the app background at this spot, so a black / light / coloured top fades into
                    // its own colour) + the list, blurred twice: a soft blur over the whole band and a very strong
                    // one near the top edge, each faded out downward -> a progressive blur.
                    val content: androidx.compose.ui.graphics.drawscope.DrawScope.() -> Unit = {
                        translate(-p.x, -p.y) { drawLayer(backdrop) }
                        drawLayer(sourceLayer)
                    }
                    veilLayer.record(size = IntSize(w, h)) { translate(-p.x, -p.y) { drawLayer(backdrop) } }
                    softLayer.record(size = IntSize(w, h), block = content)
                    strongLayer.record(size = IntSize(w, h), block = content)
                    val soft = (10f * density)
                    val strong = ((26f + 14f * s) * density)
                    softLayer.renderEffect =
                        RenderEffect.createBlurEffect(soft, soft, Shader.TileMode.CLAMP).asComposeRenderEffect()
                    strongLayer.renderEffect =
                        RenderEffect.createBlurEffect(strong, strong, Shader.TileMode.CLAMP).asComposeRenderEffect()
                    drawMasked(
                        softLayer, size.width, h.toFloat(),
                        arrayOf(0f to Color.Black.copy(alpha = s), 0.7f to Color.Black.copy(alpha = 0.9f * s), 1f to Color.Transparent)
                    )
                    drawMasked(
                        strongLayer, size.width, h.toFloat(),
                        arrayOf(
                            0f to Color.Black.copy(alpha = s),
                            0.5f to Color.Black.copy(alpha = 0.85f * s),
                            0.8f to Color.Black.copy(alpha = 0.25f * s),
                            1f to Color.Transparent
                        )
                    )
                    // haze in the background colour: thin content (text rows) dissolves into the top colour just
                    // like big cards do, so the effect looks equally strong on every screen
                    drawMasked(
                        veilLayer, size.width, h.toFloat(),
                        arrayOf(
                            0f to Color.Black.copy(alpha = 0.8f * s),
                            0.45f to Color.Black.copy(alpha = 0.5f * s),
                            1f to Color.Transparent
                        )
                    )
                }
            }
        }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawMasked(
    layer: androidx.compose.ui.graphics.layer.GraphicsLayer,
    w: Float,
    h: Float,
    stops: Array<Pair<Float, Color>>
) {
    drawIntoCanvas { canvas ->
        canvas.saveLayer(Rect(0f, 0f, w, h), Paint())
        drawLayer(layer)
        drawRect(
            brush = Brush.verticalGradient(colorStops = stops, startY = 0f, endY = h),
            size = Size(w, h),
            blendMode = BlendMode.DstIn
        )
        canvas.restore()
    }
}

package app.glassdialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.key
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.coerceAtMost
import androidx.compose.ui.zIndex
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import app.glassdialer.call.CallManager

class MainActivity : AppCompatActivity() {

    private var dialRequest by mutableStateOf<String?>(null)
    private var tabRequest by mutableStateOf<Int?>(null)
    private var tick by mutableIntStateOf(0)
    private var permTick by mutableIntStateOf(0)
    private var photoImport by mutableStateOf<List<Uri>>(emptyList())
    private var pendingDeleteId by mutableLongStateOf(-1L)
    private var deleteApproved by mutableStateOf(false)
    private var pendingSave by mutableStateOf<List<String>?>(null)
    private var saveApproved by mutableStateOf(false)

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { permTick++ }
    private val writeContactsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                deleteApproved = true
                saveApproved = true
            } else {
                pendingDeleteId = -1L
                pendingSave = null
                Toast.makeText(this, R.string.contact_save_failed, Toast.LENGTH_SHORT).show()
            }
        }
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permTick++ }
    private val imageLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
                Prefs.updateBgImage(uri.toString())
                Prefs.updateAppBg(AppBg.IMAGE)
            }
        }

    private val photosLauncher =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> photoImport = uris }

    override fun onStart() {
        super.onStart()
        CallManager.uiVisible++
    }

    override fun onStop() {
        CallManager.uiVisible = (CallManager.uiVisible - 1).coerceAtLeast(0)
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (savedInstanceState == null) handleIntent(intent)
        addOnNewIntentListener { handleIntent(it) }
        setContent { AppTheme { AppBackground { Root() } } }
    }

    override fun onResume() {
        super.onResume()
        tick++
        permTick++
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        if (i.hasExtra("tab")) tabRequest = i.getIntExtra("tab", 0)
        if (i.action == Intent.ACTION_DIAL || i.action == Intent.ACTION_VIEW) {
            val d = i.data
            dialRequest = if (d != null && d.scheme == "tel") Uri.decode(d.schemeSpecificPart ?: "") else ""
        }
    }

    private fun perms(): Array<String> {
        val l = mutableListOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.WRITE_CALL_LOG,
            Manifest.permission.WRITE_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    private fun allGranted(): Boolean = perms().all { has(it) }

    private fun requestDefault() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
                } else if (!rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
                    startActivity(Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
                }
            } else {
                roleLauncher.launch(
                    Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                        .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                )
            }
        } catch (_: Exception) {
        }
    }

    @Composable
    private fun Root() {
        val ctx = this@MainActivity
        val c = LocalColors.current

        var tab by rememberSaveable { mutableStateOf(0) }
        var showPad by rememberSaveable { mutableStateOf(false) }
        var number by rememberSaveable { mutableStateOf("") }
        var inSettings by rememberSaveable { mutableStateOf(false) }
        var detail by rememberSaveable { mutableStateOf<String?>(null) }
        var addingContact by rememberSaveable { mutableStateOf<String?>(null) }
        var query by rememberSaveable { mutableStateOf("") }
        var pending by remember { mutableStateOf<String?>(null) }

        LaunchedEffect(tab) { if (tab == 1) showPad = false }
        var confirmDelete by remember { mutableStateOf<ContactEntry?>(null) }
        val tabProgress = remember { mutableFloatStateOf(tab.toFloat()) }
        // Work that must finish (saving / deleting in the phone's contacts) runs in its own scope: resetting a
        // flag inside a LaunchedEffect would restart that effect and cancel the very job it just started.
        val scope = rememberCoroutineScope()
        val runDelete: (Long) -> Unit = { id ->
            scope.launch {
                val ok = Repo.deleteContact(ctx, id)
                Toast.makeText(ctx, if (ok) R.string.contact_deleted else R.string.contact_delete_failed, Toast.LENGTH_SHORT).show()
                if (ok) {
                    tick++
                    detail = null
                }
            }
        }
        val runSave: (List<String>) -> Unit = { req ->
            scope.launch {
                val ok = Repo.addContact(ctx, req[0], req[1], req[2], req[3])
                Toast.makeText(ctx, if (ok) R.string.contact_saved else R.string.contact_save_failed, Toast.LENGTH_SHORT).show()
                if (ok) {
                    tick++
                    addingContact = null
                }
            }
        }
        // after the permission dialog
        LaunchedEffect(deleteApproved) {
            if (deleteApproved) {
                deleteApproved = false
                val id = pendingDeleteId
                pendingDeleteId = -1L
                if (id >= 0) runDelete(id)
            }
        }
        LaunchedEffect(saveApproved) {
            if (saveApproved) {
                saveApproved = false
                val req = pendingSave
                pendingSave = null
                if (req != null) runSave(req)
            }
        }
        confirmDelete?.let { ce ->
            ConfirmDialog(
                message = stringResource(R.string.delete_contact_q, ce.name),
                confirmLabel = stringResource(R.string.delete_contact),
                onConfirm = {
                    confirmDelete = null
                    if (ctx.has(Manifest.permission.WRITE_CONTACTS)) {
                        runDelete(ce.id)
                    } else {
                        pendingDeleteId = ce.id
                        writeContactsLauncher.launch(Manifest.permission.WRITE_CONTACTS)
                    }
                },
                onDismiss = { confirmDelete = null }
            )
        }
        val pt = permTick
        val tk = tick
        val granted = remember(pt) { allGranted() }
        val isDefault = remember(pt) { isDefaultDialer(ctx) }
        val needLock = remember(pt, Prefs.lockPrompted) { needsLockScreenAccess(ctx) }
        // After the basic permissions, ask once for lock-screen access so calls can show while the phone is locked.
        LaunchedEffect(granted, needLock) {
            if (granted && needLock && !Prefs.lockPrompted) {
                delay(700)
                openLockScreenAccess(ctx)
            }
        }
        val sims = remember(pt) { simAccounts(ctx) }
        val contacts by produceState(emptyList<ContactEntry>(), tk, pt) { value = Repo.contacts(ctx) }
        val byNum = remember(contacts) { contacts.associateBy { Repo.norm(it.number) } }
        val calls by produceState(emptyList<CallEntry>(), tk, pt, byNum) { value = Repo.calls(ctx, byNum) }
        val live by CallManager.calls.collectAsState()

        val dr = dialRequest
        LaunchedEffect(dr) {
            if (dr != null) {
                number = dr
                showPad = true
                inSettings = false
                detail = null
                dialRequest = null
            }
        }
        val tr = tabRequest
        LaunchedEffect(tr) {
            if (tr != null) {
                tab = tr
                inSettings = false
                detail = null
                tabRequest = null
            }
        }
        val pi = photoImport
        LaunchedEffect(pi) {
            if (pi.isNotEmpty()) {
                val n = Repo.importPhotos(ctx, pi)
                photoImport = emptyList()
                val msg = if (n < 0) ctx.getString(R.string.need_contacts_perm) else ctx.getString(R.string.photos_imported, n)
                Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                tick++
            }
        }
        LaunchedEffect(Unit) { if (!allGranted()) permLauncher.launch(perms()) }

        fun startCall(num: String, handle: PhoneAccountHandle?) {
            if (!ctx.has(Manifest.permission.CALL_PHONE)) {
                permLauncher.launch(perms())
                return
            }
            placeCall(ctx, num, handle)
        }

        fun dial(num: String) {
            if (num.isBlank()) return
            when {
                sims.size < 2 -> startCall(num, sims.firstOrNull()?.handle)
                Prefs.defaultSim in sims.indices -> startCall(num, sims[Prefs.defaultSim].handle)
                else -> pending = num
            }
        }

        val suggestion = remember(number, contacts) {
            val d = number.filter { it.isDigit() }
            if (d.length < 3) null
            else contacts.firstOrNull { it.number.filter { ch -> ch.isDigit() }.contains(d) }?.name
        }

        BackHandler(enabled = inSettings || detail != null || addingContact != null || showPad) {
            when {
                addingContact != null -> addingContact = null
                detail != null -> detail = null
                inSettings -> inSettings = false
                else -> showPad = false
            }
        }

        val screen = if (inSettings) 1 else if (addingContact != null) 3 else if (detail != null) 2 else 0
        AnimatedContent(
            targetState = screen,
            transitionSpec = {
                if (!Prefs.motion) {
                    EnterTransition.None togetherWith ExitTransition.None
                } else {
                    (fadeIn(tween(260)) + scaleIn(tween(300), initialScale = 0.96f)) togetherWith
                        fadeOut(tween(180))
                }
            },
            label = "screen"
        ) { s ->
            when (s) {
                1 -> SettingsScreen(
                    sims, isDefault,
                    { requestDefault() },
                    { imageLauncher.launch(arrayOf("image/*")) },
                    { photosLauncher.launch(arrayOf("image/*")) },
                    { inSettings = false }
                )

                3 -> AddContactScreen(
                    initialNumber = addingContact ?: "",
                    onBack = { addingContact = null },
                    onSave = { f, l, n, note ->
                        val req = listOf(f, l, n, note)
                        if (ctx.has(Manifest.permission.WRITE_CONTACTS)) {
                            runSave(req)
                        } else {
                            pendingSave = req
                            writeContactsLauncher.launch(Manifest.permission.WRITE_CONTACTS)
                        }
                    }
                )

                2 -> {
                    val dn = detail ?: ""
                    val hist = calls.filter { Repo.norm(it.number) == Repo.norm(dn) }
                    val first = hist.firstOrNull()
                    val contact = byNum[Repo.norm(dn)]
                    DetailScreen(
                        number = dn, name = contact?.name ?: first?.name, photo = contact?.photo ?: first?.photo, history = hist,
                        onBack = { detail = null },
                        onCall = { dial(dn) },
                        onVideo = { placeCall(ctx, dn, null, true) },
                        onDeleted = {
                            tick++
                            detail = null
                        },
                        onDeleteContact = if (contact != null) ({ confirmDelete = contact }) else null,
                        onNewContact = { addingContact = dn }
                    )
                }

                else -> key(tk) {
                  // key(tk): rebuild this screen whenever the app resumes, so touch handling is fresh after returning.
                  // Records the lists so the floating bottom bar / dial pad can blur what scrolls behind them.
                  val contentLayer = rememberGraphicsLayer()
                  val land = isLandscape()
                  val screenW = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp.dp
                  val padW = (screenW * 0.42f).coerceAtMost(380.dp)
                  val listEnd by androidx.compose.animation.core.animateDpAsState(
                      if (land && showPad) padW + 16.dp else 0.dp, tween(260), label = "listEnd"
                  )
                  Box(Modifier.fillMaxSize()) {
                    // The pages fill the whole screen and scroll UNDER the floating header (no clipped rectangle on
                    // top): the content blurs / fades into the background colour as it goes up. Both pages stay
                    // composed; the page follows the bottom-bar capsule, so switching never waits for anything.
                    val topPad = statusBarTop() + 60.dp + (if (live.isNotEmpty()) 52.dp else 0.dp)
                    Box(
                        Modifier.fillMaxSize()
                            .padding(end = listEnd)
                            .drawWithContent {
                                contentLayer.record { this@drawWithContent.drawContent() }
                                drawLayer(contentLayer)
                            }
                    ) {
                        Box(
                            Modifier.fillMaxSize().zIndex(if (tab == 0) 1f else 0f).graphicsLayer {
                                val pr = tabProgress.floatValue.coerceIn(0f, 1f)
                                alpha = 1f - pr
                                translationX = if (Prefs.motion) -pr * size.width * 0.33f else 0f
                            }
                        ) {
                                RecentsList(
                                    calls = calls,
                                    top = {
                                        Column {
                                            if (!granted) {
                                                Banner(
                                                    stringResource(R.string.perms_title), stringResource(R.string.perms_desc),
                                                    stringResource(R.string.grant)
                                                ) { permLauncher.launch(perms()) }
                                            }
                                            if (needLock) {
                                                Banner(
                                                    stringResource(R.string.lock_title), stringResource(R.string.lock_desc),
                                                    stringResource(R.string.lock_grant)
                                                ) { openLockScreenAccess(ctx) }
                                            }
                                            if (!isDefault) {
                                                Banner(
                                                    stringResource(R.string.default_title), stringResource(R.string.default_desc),
                                                    stringResource(R.string.set_default)
                                                ) { requestDefault() }
                                            }
                                        }
                                    },
                                    bottomPad = 130.dp,
                                    onCall = { dial(it) },
                                    onInfo = { detail = it.number },
                                    topInset = topPad
                                )
                        }
                        Box(
                            Modifier.fillMaxSize().zIndex(if (tab == 1) 1f else 0f).graphicsLayer {
                                val pr = tabProgress.floatValue.coerceIn(0f, 1f)
                                alpha = pr
                                translationX = if (Prefs.motion) (1f - pr) * size.width * 0.33f else 0f
                            }
                        ) {
                                ContactsList(contacts, query, { query = it }, 130.dp, topPad) { detail = it }
                        }
                        Column(Modifier.statusBarsPadding().zIndex(2f)) {
                        AnimatedContent(
                            targetState = tab,
                            transitionSpec = {
                                fadeIn(tween(220)) togetherWith fadeOut(tween(160))
                            },
                            label = "title"
                        ) { t ->
                            TopBar(stringResource(if (t == 0) R.string.recents else R.string.contacts)) {
                                Box(Modifier.size(44.dp).tap { inSettings = true }, contentAlignment = Alignment.Center) {
                                    Icon(Ic.settings, null, tint = c.sub)
                                }
                            }
                        }
                        if (live.isNotEmpty()) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                                    .tap { safeStart(ctx, Intent(ctx, InCallActivity::class.java)) }
                                    .clip(RoundedCornerShape(18.dp)).background(c.accent).padding(vertical = 9.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Ic.call, null, Modifier.size(16.dp), tint = Color.White)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    stringResource(R.string.return_to_call), color = Color.White,
                                    fontSize = 14.sp, fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        }
                    }

                    CompositionLocalProvider(LocalContentBackdrop provides contentLayer) {
                    val padCard: @Composable () -> Unit = {
                        AnimatedVisibility(
                            visible = showPad,
                            enter = fadeIn(tween(180)) +
                                slideInVertically(spring(stiffness = Spring.StiffnessMediumLow)) { it / 3 } +
                                scaleIn(initialScale = 0.92f),
                            exit = fadeOut(tween(140)) +
                                slideOutVertically(tween(180)) { it / 3 } +
                                scaleOut(targetScale = 0.92f)
                        ) {
                            Column {
                                DialPadCard(
                                    number = number,
                                    suggestion = suggestion,
                                    sims = sims,
                                    onKey = { ch -> if (number.length < 30) number += ch },
                                    onDelete = { number = number.dropLast(1) },
                                    onClear = { number = "" },
                                    onCall = { handle -> if (number.isNotEmpty()) startCall(number, handle) }
                                )
                                if (!land) Spacer(Modifier.height(12.dp))
                            }
                        }
                    }
                    if (land) {
                        // Landscape: dial pad on the right side, bottom bar stays on the left.
                        Box(
                            Modifier.align(Alignment.CenterEnd).fillMaxHeight().statusBarsPadding().navigationBarsPadding()
                                .padding(end = 16.dp).width(padW),
                            contentAlignment = Alignment.Center
                        ) { padCard() }
                        Column(
                            Modifier.align(Alignment.BottomStart).navigationBarsPadding()
                                .padding(start = 16.dp).padding(bottom = 8.dp)
                        ) {
                            BottomNav(tab, { tab = it }, showPad, { tabProgress.floatValue = it }) {
                                if (tab == 1) addingContact = "" else showPad = !showPad
                            }
                        }
                    } else {
                        Column(
                            Modifier.align(Alignment.BottomCenter).navigationBarsPadding()
                                .padding(horizontal = 16.dp).padding(bottom = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            padCard()
                            BottomNav(tab, { tab = it }, showPad, { tabProgress.floatValue = it }) {
                                if (tab == 1) addingContact = "" else showPad = !showPad
                            }
                        }
                    }
                    }
                  }
                }
            }
        }

        val pn = pending
        if (pn != null) {
            AlertDialog(
                onDismissRequest = { pending = null },
                containerColor = c.surfaceHigh,
                title = { Text(stringResource(R.string.choose_sim), color = c.text) },
                text = {
                    Column {
                        sims.forEach { s ->
                            Text(
                                s.label, color = c.text, fontSize = 17.sp,
                                modifier = Modifier.fillMaxWidth().tap {
                                    startCall(pn, s.handle)
                                    pending = null
                                }.padding(vertical = 14.dp)
                            )
                        }
                    }
                },
                confirmButton = {}
            )
        }
    }
}

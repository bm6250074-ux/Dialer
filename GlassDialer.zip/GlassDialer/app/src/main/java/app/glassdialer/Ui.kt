package app.glassdialer

import android.content.Context
import android.net.Uri
import android.text.format.DateFormat
import android.text.format.DateUtils
import android.util.LruCache
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Date

/** All icons in one place so other files never import icon names that clash with telecom classes. */
/** Just the person figure (head + shoulders), like the blue contacts icon. */
private fun buildContactPerson(): ImageVector =
    ImageVector.Builder(
        name = "ContactPerson",
        defaultWidth = 24.dp, defaultHeight = 24.dp,
        viewportWidth = 24f, viewportHeight = 24f
    )
        .path(fill = SolidColor(Color.Black)) {
            moveTo(7.8f, 8.2f)
            arcTo(4.2f, 4.2f, 0f, true, true, 16.2f, 8.2f)
            arcTo(4.2f, 4.2f, 0f, true, true, 7.8f, 8.2f)
            close()
        }
        .path(fill = SolidColor(Color.Black)) {
            moveTo(7.7f, 14.4f)
            horizontalLineTo(16.3f)
            arcTo(3.5f, 3.5f, 0f, false, true, 19.8f, 17.9f)
            verticalLineTo(18.9f)
            arcTo(1.8f, 1.8f, 0f, false, true, 18f, 20.7f)
            horizontalLineTo(6f)
            arcTo(1.8f, 1.8f, 0f, false, true, 4.2f, 18.9f)
            verticalLineTo(17.9f)
            arcTo(3.5f, 3.5f, 0f, false, true, 7.7f, 14.4f)
            close()
        }
        .build()

/** Filled camera body with a small lens dot — video call. */
private fun buildVideoCallIcon(): ImageVector =
    ImageVector.Builder(name = "VideoCallIcon", defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f)
        .path(fill = SolidColor(Color.Black)) {
            moveTo(3f, 7.5f)
            arcTo(2f, 2f, 0f, false, true, 5f, 5.5f)
            horizontalLineTo(13f)
            arcTo(2f, 2f, 0f, false, true, 15f, 7.5f)
            verticalLineTo(16.5f)
            arcTo(2f, 2f, 0f, false, true, 13f, 18.5f)
            horizontalLineTo(5f)
            arcTo(2f, 2f, 0f, false, true, 3f, 16.5f)
            close()
        }
        .path(fill = SolidColor(Color.Black)) {
            moveTo(16.3f, 10f)
            lineTo(20.2f, 7.4f)
            arcTo(1f, 1f, 0f, false, true, 21.7f, 8.2f)
            verticalLineTo(15.8f)
            arcTo(1f, 1f, 0f, false, true, 20.2f, 16.6f)
            lineTo(16.3f, 14f)
            close()
        }
        .build()

/** 3x3 dot grid — keypad. */
private fun buildKeypadIcon(): ImageVector =
    ImageVector.Builder(name = "KeypadIcon", defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f)
        .apply {
            val cx = floatArrayOf(6.3f, 12f, 17.7f)
            val cy = floatArrayOf(6.3f, 12f, 17.7f)
            for (y in cy) for (x in cx) {
                path(fill = SolidColor(Color.Black)) {
                    moveTo(x + 1.7f, y)
                    arcTo(1.7f, 1.7f, 0f, true, true, x - 1.7f, y)
                    arcTo(1.7f, 1.7f, 0f, true, true, x + 1.7f, y)
                    close()
                }
            }
        }
        .build()

/** Mic capsule with stand and a diagonal slash — muted mic. */
private fun buildMicMutedIcon(): ImageVector =
    ImageVector.Builder(name = "MicMutedIcon", defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f)
        .path(fill = SolidColor(Color.Black)) {
            moveTo(12f, 2.5f)
            arcTo(3.2f, 3.2f, 0f, false, true, 15.2f, 5.7f)
            verticalLineTo(11.4f)
            arcTo(3.2f, 3.2f, 0f, false, true, 8.8f, 11.4f)
            verticalLineTo(5.7f)
            arcTo(3.2f, 3.2f, 0f, false, true, 12f, 2.5f)
            close()
        }
        .path(fill = SolidColor(Color.Black)) {
            moveTo(6.3f, 10.5f)
            arcTo(0.9f, 0.9f, 0f, false, true, 8.1f, 10.5f)
            curveTo(8.1f, 13.6f, 9.9f, 15.5f, 12f, 15.5f)
            curveTo(12.9f, 15.5f, 13.7f, 15.2f, 14.3f, 14.6f)
            lineTo(15.6f, 15.9f)
            curveTo(14.8f, 16.7f, 13.8f, 17.2f, 12.7f, 17.3f)
            verticalLineTo(19.3f)
            horizontalLineTo(14.3f)
            arcTo(0.9f, 0.9f, 0f, false, true, 14.3f, 21.1f)
            horizontalLineTo(9.7f)
            arcTo(0.9f, 0.9f, 0f, false, true, 9.7f, 19.3f)
            horizontalLineTo(11.3f)
            verticalLineTo(17.3f)
            curveTo(8.4f, 16.9f, 6.3f, 14.4f, 6.3f, 10.5f)
            close()
        }
        .path(fill = SolidColor(Color.Black)) {
            moveTo(4.6f, 3.3f)
            lineTo(20.7f, 19.4f)
            lineTo(19.4f, 20.7f)
            lineTo(3.3f, 4.6f)
            close()
        }
        .build()

/** Plain filled rounded square — note (matches the simple reference icon exactly). */
/**
 * Note/document with a folded top-right corner and two inner "lines" of text — the classic note
 * icon. Icon() applies a single uniform tint to the whole vector, so this is one path: the lines
 * and are cut out as holes (even-odd fill) rather than drawn in a second colour, which would be
 * overridden by the tint anyway.
 */
private fun buildNoteDocIcon(): ImageVector =
    ImageVector.Builder(name = "NoteDocIcon", defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f)
        .path(fill = SolidColor(Color.Black), pathFillType = androidx.compose.ui.graphics.PathFillType.EvenOdd) {
            // Page body with the top-right corner cut away for the fold.
            moveTo(5.5f, 3.5f)
            horizontalLineTo(14.5f)
            lineTo(19f, 8f)
            verticalLineTo(19f)
            arcTo(1.5f, 1.5f, 0f, false, true, 17.5f, 20.5f)
            horizontalLineTo(5.5f)
            arcTo(1.5f, 1.5f, 0f, false, true, 4f, 19f)
            verticalLineTo(5f)
            arcTo(1.5f, 1.5f, 0f, false, true, 5.5f, 3.5f)
            close()
            // Two lines, cut out of the page as holes.
            moveTo(7f, 11.2f)
            horizontalLineTo(16f)
            verticalLineTo(12.6f)
            horizontalLineTo(7f)
            close()
            moveTo(7f, 14.6f)
            horizontalLineTo(13.5f)
            verticalLineTo(16f)
            horizontalLineTo(7f)
            close()
        }
        .build()

/** Speaker trapezoid with two sound-wave arcs. */
private fun buildSpeakerIcon(): ImageVector =
    ImageVector.Builder(name = "SpeakerIcon", defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f)
        .path(fill = SolidColor(Color.Black)) {
            moveTo(3.5f, 9.5f)
            horizontalLineTo(6.8f)
            lineTo(11.3f, 5.8f)
            arcTo(0.8f, 0.8f, 0f, false, true, 12.6f, 6.4f)
            verticalLineTo(17.6f)
            arcTo(0.8f, 0.8f, 0f, false, true, 11.3f, 18.2f)
            lineTo(6.8f, 14.5f)
            horizontalLineTo(3.5f)
            arcTo(1f, 1f, 0f, false, true, 2.5f, 13.5f)
            verticalLineTo(10.5f)
            arcTo(1f, 1f, 0f, false, true, 3.5f, 9.5f)
            close()
        }
        .apply {
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.Black), strokeLineWidth = 1.6f, strokeLineCap = StrokeCap.Round
            ) {
                moveTo(15.8f, 8.3f)
                curveTo(17.2f, 9.4f, 18f, 10.7f, 18f, 12f)
                curveTo(18f, 13.3f, 17.2f, 14.6f, 15.8f, 15.7f)
            }
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.Black), strokeLineWidth = 1.6f, strokeLineCap = StrokeCap.Round
            ) {
                moveTo(18.1f, 5.6f)
                curveTo(20.2f, 7.3f, 21.3f, 9.5f, 21.3f, 12f)
                curveTo(21.3f, 14.5f, 20.2f, 16.7f, 18.1f, 18.4f)
            }
        }
        .build()

object Ic {
    val call = Icons.Filled.Call
    val callEnd = Icons.Filled.CallEnd
    val backspace = Icons.Filled.Backspace
    val back = Icons.AutoMirrored.Filled.ArrowBack
    val chevronRight = Icons.AutoMirrored.Filled.KeyboardArrowRight
    val settings = Icons.Filled.Settings
    val dialpad = Icons.Filled.Dialpad
    val history = Icons.Filled.History
    val contactPerson: ImageVector = buildContactPerson()
    val videoCallIcon: ImageVector = buildVideoCallIcon()
    val keypadIcon: ImageVector = buildKeypadIcon()
    val micMutedIcon: ImageVector = buildMicMutedIcon()
    val noteDocIcon: ImageVector = buildNoteDocIcon()
    val speakerIcon: ImageVector = buildSpeakerIcon()
    val person = Icons.Filled.Person
    val personAdd = Icons.Filled.PersonAdd
    val videocam = Icons.Filled.Videocam
    val message = Icons.Filled.Message
    val search = Icons.Filled.Search
    val mic = Icons.Filled.Mic
    val micOff = Icons.Filled.MicOff
    val volumeUp = Icons.Filled.VolumeUp
    val speaker = Icons.Filled.VolumeDown
    val pause = Icons.Filled.Pause
    val play = Icons.Filled.PlayArrow
    val add = Icons.Filled.Add
    val bluetooth = Icons.Filled.Bluetooth
    val made = Icons.Filled.CallMade
    val received = Icons.Filled.CallReceived
    val missed = Icons.Filled.CallMissed
    val delete = Icons.Filled.Delete
    val info = Icons.Outlined.Info
    val check = Icons.Filled.Check
    val note = Icons.Filled.Description
    val keyboardDown = Icons.Filled.KeyboardArrowDown
    val keyboardUp = Icons.Filled.KeyboardArrowUp
}

/** Plain click without any indication. */
fun Modifier.tap(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    clickable(
        enabled = enabled,
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick
    )
}

/** Click with a small spring-like press scale. Put it BEFORE clip/background in the chain. */
fun Modifier.bounce(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.9f else 1f,
        spring(dampingRatio = 0.45f, stiffness = 500f),
        label = "bounce"
    )
    this.scale(s).clickable(enabled = enabled, interactionSource = src, indication = null, onClick = onClick)
}

object PhotoCache {
    private val cache = LruCache<String, ImageBitmap>(80)

    suspend fun load(ctx: Context, uri: String): ImageBitmap? = withContext(Dispatchers.IO) {
        cache.get(uri) ?: try {
            ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { s ->
                BitmapFactory.decodeStream(s)?.asImageBitmap()
            }?.also { cache.put(uri, it) }
        } catch (_: Throwable) {
            null
        }
    }
}

private val avatarColors = listOf(0xFF3B82F6, 0xFF22C55E, 0xFFF59E0B, 0xFFEF4444, 0xFF8B5CF6, 0xFF14B8A6, 0xFFEC4899)

/** A contact's picture: their own photo if they have one, otherwise a plain generic
 *  silhouette on a neutral background — never an initial letter. */
@Composable
fun Avatar(name: String?, photo: String?, size: Dp, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, photo) {
        value = if (photo == null) null else PhotoCache.load(ctx, photo)
    }
    val c = LocalColors.current
    Box(
        modifier.size(size).clip(CircleShape)
            .background(if (c.dark) Color(0xFF4A4A52) else Color(0xFFBFC3CC)),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(bitmap = b, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Icon(Ic.person, null, Modifier.size(size * 0.62f), tint = if (c.dark) Color(0xFF8A8A92) else Color.White)
        }
    }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)? = null, trailing: @Composable RowScope.() -> Unit = {}) {
    val c = LocalColors.current
    Row(
        Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            Box(Modifier.size(44.dp).tap(onClick = onBack), contentAlignment = Alignment.Center) {
                Icon(Ic.back, null, tint = c.text)
            }
        } else Spacer(Modifier.width(8.dp))
        Text(
            title, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, modifier = Modifier.weight(1f).padding(horizontal = 6.dp)
        )
        trailing()
    }
}

@Composable
fun EmptyState(text: String) {
    val c = LocalColors.current
    Box(Modifier.fillMaxWidth().padding(top = 80.dp), contentAlignment = Alignment.Center) {
        Text(text, color = c.sub, fontSize = 16.sp)
    }
}

fun fmtDate(ctx: Context, ms: Long): String = when {
    DateUtils.isToday(ms) -> DateFormat.getTimeFormat(ctx).format(Date(ms))
    DateUtils.isToday(ms + DateUtils.DAY_IN_MILLIS) -> ctx.getString(R.string.yesterday)
    else -> DateFormat.getDateFormat(ctx).format(Date(ms))
}

/** Fade + slide-up when an item first appears. */
fun Modifier.enterAnim(index: Int = 0): Modifier = composed {
    if (!Prefs.motion || index >= 10) {
        this
    } else {
        val a = remember { Animatable(0f) }
        LaunchedEffect(Unit) {
            a.animateTo(1f, tween(380, delayMillis = index.coerceAtMost(8) * 35, easing = FastOutSlowInEasing))
        }
        this.graphicsLayer {
            alpha = a.value
            translationY = (1f - a.value) * 36f
        }
    }
}

suspend fun loadBackground(ctx: Context, uri: String): Bitmap? = withContext(Dispatchers.IO) {
    try {
        val u = Uri.parse(uri)
        val opts = BitmapFactory.Options()
        opts.inJustDecodeBounds = true
        ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (opts.outWidth / (sample * 2) >= 1080 || opts.outHeight / (sample * 2) >= 1920) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
    } catch (_: Throwable) {
        null
    }
}

private fun boxBlurPass(pixels: IntArray, w: Int, h: Int, radius: Int) {
    val tmp = IntArray(w * h)
    for (y in 0 until h) {
        val row = y * w
        for (x in 0 until w) {
            var a = 0; var r = 0; var g = 0; var b = 0; var n = 0
            for (k in -radius..radius) {
                val xx = (x + k).coerceIn(0, w - 1)
                val p = pixels[row + xx]
                a += (p ushr 24) and 0xFF; r += (p ushr 16) and 0xFF
                g += (p ushr 8) and 0xFF; b += p and 0xFF; n++
            }
            tmp[row + x] = ((a / n) shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
        }
    }
    for (x in 0 until w) {
        for (y in 0 until h) {
            var a = 0; var r = 0; var g = 0; var b = 0; var n = 0
            for (k in -radius..radius) {
                val yy = (y + k).coerceIn(0, h - 1)
                val p = tmp[yy * w + x]
                a += (p ushr 24) and 0xFF; r += (p ushr 16) and 0xFF
                g += (p ushr 8) and 0xFF; b += p and 0xFF; n++
            }
            pixels[y * w + x] = ((a / n) shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
        }
    }
}

/**
 * A real soft blur instead of the old "shrink hard, stretch back up" trick, which looked blocky
 * and pixelated at anything but a low radius. This shrinks to a small fixed working size, runs a
 * few box-blur passes (which approximate a Gaussian blur), then scales back up — the box-blurred
 * source is already smooth, so the final upscale looks soft rather than pixelated. Still a
 * one-time CPU operation (not per-frame), so it stays cheap.
 */
fun blurBitmap(src: Bitmap, blur: Int): Bitmap {
    if (blur <= 0) return src
    return try {
        val target = 150
        val longest = maxOf(src.width, src.height).coerceAtLeast(1)
        val scale = target.toFloat() / longest
        val sw = (src.width * scale).toInt().coerceAtLeast(8)
        val sh = (src.height * scale).toInt().coerceAtLeast(8)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
            .copy(Bitmap.Config.ARGB_8888, true)
        val pixels = IntArray(sw * sh)
        small.getPixels(pixels, 0, sw, 0, 0, sw, sh)
        val radius = (1 + blur / 10).coerceIn(1, 11)
        repeat(3) { boxBlurPass(pixels, sw, sh, radius) }
        small.setPixels(pixels, 0, sw, 0, 0, sw, sh)
        Bitmap.createScaledBitmap(small, src.width, src.height, true)
    } catch (_: Throwable) {
        src
    }
}

@Composable
fun BlurredBitmap(bitmap: Bitmap, blur: Int, dim: Int) {
    val shown = remember(bitmap, blur) { blurBitmap(bitmap, blur).asImageBitmap() }
    Image(
        bitmap = shown, contentDescription = null, contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize(), filterQuality = FilterQuality.High
    )
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = (dim / 100f).coerceIn(0f, 0.9f))))
}

@Composable
fun BackgroundImage(uri: String, blur: Int, dim: Int) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) {
        value = if (uri.isEmpty()) null else loadBackground(ctx, uri)
    }
    val b = bmp
    if (b != null) BlurredBitmap(b, blur, dim)
}

package app.glassdialer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.telecom.TelecomManager
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.flow.first
import androidx.compose.ui.layout.layout
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.runtime.rememberUpdatedState

@Composable
fun Banner(title: String, desc: String, button: String, onClick: () -> Unit) {
    val c = LocalColors.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .glass(RoundedCornerShape(22.dp)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(desc, color = c.sub, fontSize = 13.sp)
        }
        Spacer(Modifier.width(12.dp))
        Box(
            Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(16.dp)).background(c.accent)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) { Text(button, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
fun RecentsList(
    calls: List<CallEntry>,
    top: @Composable () -> Unit,
    bottomPad: Dp,
    onCall: (String) -> Unit,
    onInfo: (CallEntry) -> Unit,
    topInset: Dp = 0.dp
) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val listState = rememberLazyListState()
    LazyColumn(
        Modifier.fillMaxSize().topScrollBlur(topInset + 28.dp) { listState.scrollBlurStrength() },
        state = listState,
        contentPadding = PaddingValues(top = topInset, bottom = bottomPad)
    ) {
        item { top() }
        if (calls.isEmpty()) item { EmptyState(stringResource(R.string.no_calls)) }
        itemsIndexed(calls, key = { _, e -> e.id }) { i, e ->
            val missed = e.type == 3 || e.type == 5
            val base = e.name ?: if (e.number.isBlank()) stringResource(R.string.private_number) else prettyNumber(e.number)
            val title = if (e.count > 1) base + " (" + e.count + ")" else base
            val typeIcon = when (e.type) {
                1 -> Ic.received
                3, 5 -> Ic.missed
                else -> Ic.made
            }
            Row(
                Modifier.fillMaxWidth().enterAnim(i).tap { onCall(e.number) }
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(e.name, e.photo, 46.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title, color = if (missed) c.danger else c.text, fontSize = 17.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        fmtDate(ctx, e.date), color = c.sub, fontSize = 13.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                // round button -> contact info (only in Recents)
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(c.text.copy(alpha = 0.12f)).tap { onInfo(e) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Ic.chevronRight, null, Modifier.size(24.dp), tint = c.sub)
                }
            }
        }
    }
}

@Composable
fun ContactsList(
    contacts: List<ContactEntry>,
    query: String,
    onQuery: (String) -> Unit,
    bottomPad: Dp,
    topInset: Dp = 0.dp,
    onOpen: (String) -> Unit
) {
    val c = LocalColors.current
    val filtered = remember(contacts, query) {
        if (query.isBlank()) contacts
        else {
            val qd = query.filter { it.isDigit() }.ifEmpty { "\u0000" }
            contacts.filter { it.name.contains(query, ignoreCase = true) || it.number.filter { ch -> ch.isDigit() }.contains(qd) }
        }
    }
    val listState = rememberLazyListState()
    run {
        LazyColumn(
            Modifier.fillMaxSize().topScrollBlur(topInset + 28.dp) { listState.scrollBlurStrength() },
            state = listState,
            contentPadding = PaddingValues(top = topInset, bottom = bottomPad)
        ) {
            item {
                BasicTextField(
                    value = query, onValueChange = onQuery, singleLine = true,
                    textStyle = TextStyle(color = c.text, fontSize = 16.sp),
                    cursorBrush = SolidColor(c.accent),
                    decorationBox = { inner ->
                        Row(Modifier.fillMaxHeight(), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Ic.search, null, Modifier.size(20.dp), tint = c.sub)
                            Spacer(Modifier.width(10.dp))
                            Box(Modifier.weight(1f)) {
                                if (query.isEmpty()) Text(stringResource(R.string.search_contacts), color = c.sub, fontSize = 16.sp)
                                inner()
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).height(52.dp)
                        .glass(RoundedCornerShape(26.dp)).padding(horizontal = 16.dp)
                )
            }
            if (filtered.isEmpty()) item { EmptyState(stringResource(R.string.no_contacts)) }
            itemsIndexed(filtered, key = { _, e -> e.id.toString() + ":" + Repo.norm(e.number) }) { i, e ->
                val letter = e.name.firstOrNull { it.isLetter() }?.uppercaseChar() ?: '#'
                val prev = if (i > 0) filtered[i - 1].name.firstOrNull { it.isLetter() }?.uppercaseChar() ?: '#' else null
                Column(Modifier.fillMaxWidth().enterAnim(i)) {
                    if (prev != letter) {
                        Text(
                            letter.toString(), color = c.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(start = 24.dp, top = 12.dp, bottom = 2.dp)
                        )
                    }
                    Row(
                        Modifier.fillMaxWidth().tap { onOpen(e.number) }.padding(horizontal = 20.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(e.name, e.photo, 44.dp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(e.name, color = c.text, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(prettyNumber(e.number), color = c.sub, fontSize = 13.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

private class Act(val label: String, val icon: ImageVector, val color: Color, val run: () -> Unit)

@Composable
fun DetailScreen(
    number: String,
    name: String?,
    photo: String?,
    history: List<CallEntry>,
    onBack: () -> Unit,
    onCall: () -> Unit,
    onVideo: () -> Unit,
    onDeleted: () -> Unit,
    onDeleteContact: (() -> Unit)? = null,
    onNewContact: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val noteText = remember(number) { Prefs.note(number) }
    var showAll by remember(number) { mutableStateOf(false) }
    val green = Color(0xFF2AE93E)
    val shown = if (showAll) history else history.take(3)

    val headerTop = statusBarTop() + 60.dp
    Box(Modifier.fillMaxSize()) {
        val listState = rememberLazyListState()
        LazyColumn(
            Modifier.fillMaxSize().topScrollBlur(headerTop + 28.dp) { listState.scrollBlurStrength() },
            state = listState,
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = headerTop, bottom = 40.dp)
        ) {
            item {
                Column(
                    Modifier.fillMaxWidth().enterAnim(0).padding(top = 20.dp, bottom = 34.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Avatar(name, photo, 124.dp)
                    Spacer(Modifier.height(26.dp))
                    Text(
                        name ?: stringResource(R.string.unknown_contact), color = c.text, fontSize = 34.sp,
                        fontWeight = FontWeight.Normal, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (noteText.isNotEmpty()) {
                item {
                    Row(
                        Modifier.fillMaxWidth().enterAnim(1).glass(RoundedCornerShape(28.dp)).padding(18.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(Ic.note, null, Modifier.size(20.dp), tint = c.sub)
                        Spacer(Modifier.width(12.dp))
                        Text(noteText, color = c.text, fontSize = 15.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
            // number + call / message buttons (+ New / Existing for unknown numbers)
            item {
                Column(Modifier.fillMaxWidth().enterAnim(2).glass(RoundedCornerShape(28.dp)).padding(horizontal = 20.dp, vertical = 14.dp)) {
                    Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            prettyNumber(number), color = c.text, fontSize = 18.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                        Box(
                            Modifier.size(46.dp).clip(CircleShape).background(green.copy(alpha = 0.16f)).tap(onClick = onCall),
                            contentAlignment = Alignment.Center
                        ) { Icon(Ic.call, null, Modifier.size(24.dp), tint = green) }
                        Spacer(Modifier.width(14.dp))
                        Box(
                            Modifier.size(46.dp).clip(CircleShape).background(green.copy(alpha = 0.16f))
                                .tap { safeStart(ctx, smsIntent(number)) },
                            contentAlignment = Alignment.Center
                        ) { Icon(Ic.message, null, Modifier.size(24.dp), tint = green) }
                    }
                    if (name == null) {
                        Spacer(Modifier.height(14.dp))
                        Text(
                            stringResource(R.string.contact_new), color = c.link, fontSize = 20.sp, fontWeight = FontWeight.Medium,
                            modifier = Modifier.fillMaxWidth().tap(onClick = onNewContact).padding(vertical = 14.dp)
                        )
                        Text(
                            stringResource(R.string.contact_existing), color = c.link, fontSize = 20.sp, fontWeight = FontWeight.Medium,
                            modifier = Modifier.fillMaxWidth().tap { safeStart(ctx, addToContactIntent(number)) }.padding(vertical = 14.dp)
                        )
                    }
                }
            }
            if (history.isNotEmpty()) {
                item {
                    Text(
                        stringResource(R.string.call_history), color = c.sub, fontSize = 15.sp,
                        modifier = Modifier.padding(start = 22.dp, top = 28.dp, bottom = 10.dp)
                    )
                }
                item {
                    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp)).padding(vertical = 6.dp)) {
                        shown.forEach { e ->
                            val missed = e.type == 3 || e.type == 5
                            val label = when {
                                e.type == 1 -> stringResource(R.string.ct_incoming)
                                e.type == 3 -> stringResource(R.string.ct_missed)
                                e.type == 5 -> stringResource(R.string.ct_declined)
                                e.duration > 0 -> stringResource(R.string.ct_outgoing)
                                else -> stringResource(R.string.ct_not_connected)
                            }
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        java.text.SimpleDateFormat("d. MMM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(e.date)),
                                        color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Medium
                                    )
                                    Spacer(Modifier.height(3.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            when (e.type) {
                                                1 -> Ic.received
                                                3, 5 -> Ic.missed
                                                else -> Ic.made
                                            },
                                            null, Modifier.size(18.dp), tint = if (missed) c.danger else c.sub
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            if (e.duration > 0) label + "  ·  " + fmtTime(e.duration) else label,
                                            color = if (missed) c.danger else c.sub, fontSize = 15.sp
                                        )
                                    }
                                }
                                Icon(Ic.chevronRight, null, Modifier.size(24.dp), tint = c.sub)
                            }
                        }
                        if (history.size > 3) {
                            Text(
                                stringResource(if (showAll) R.string.show_less else R.string.show_more),
                                color = c.link, fontSize = 20.sp, fontWeight = FontWeight.Medium,
                                modifier = Modifier.fillMaxWidth().tap { showAll = !showAll }.padding(horizontal = 20.dp, vertical = 16.dp)
                            )
                        }
                    }
                }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(top = 22.dp).glass(RoundedCornerShape(28.dp)).padding(horizontal = 20.dp)) {
                    Text(
                        stringResource(R.string.video_call), color = c.link, fontSize = 18.sp,
                        modifier = Modifier.fillMaxWidth().tap(onClick = onVideo).padding(vertical = 16.dp)
                    )
                    if (onDeleteContact != null) {
                        Text(
                            stringResource(R.string.delete_contact), color = c.danger, fontSize = 18.sp,
                            modifier = Modifier.fillMaxWidth().tap(onClick = onDeleteContact).padding(vertical = 16.dp)
                        )
                    }
                    Text(
                        stringResource(R.string.delete_entry_short), color = c.danger, fontSize = 18.sp,
                        modifier = Modifier.fillMaxWidth().tap {
                            Repo.deleteNumber(ctx, number)
                            onDeleted()
                        }.padding(vertical = 16.dp)
                    )
                }
            }
        }
        FloatingBack(onBack)
    }
}

@Composable
fun <T> ChipGroup(options: List<Pair<String, T>>, selected: T, perRow: Int = 2, onSelect: (T) -> Unit) {
    val c = LocalColors.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.chunked(perRow).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (label, v) ->
                    val sel = v == selected
                    Box(
                        Modifier.weight(1f).height(44.dp).bounce { onSelect(v) }
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (sel) c.accent else c.text.copy(alpha = 0.08f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            label, color = if (sel) Color.White else c.text, fontSize = 14.sp,
                            fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                repeat(perRow - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, index: Int, content: @Composable () -> Unit) {
    val c = LocalColors.current
    Column(
        Modifier.fillMaxWidth().enterAnim(index).glass(RoundedCornerShape(24.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, color = c.sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        content()
    }
}

@Composable
private fun SubLabel(text: String) {
    Text(text, color = LocalColors.current.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalColors.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = c.accent, checkedThumbColor = Color.White)
        )
    }
}

@Composable
private fun SliderRow(label: String, value: Int, min: Int, max: Int, suffix: String = "", onChange: (Int) -> Unit) {
    val c = LocalColors.current
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text(value.toString() + suffix, color = c.sub, fontSize = 14.sp)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = min.toFloat()..max.toFloat(),
            colors = SliderDefaults.colors(
                thumbColor = c.accent, activeTrackColor = c.accent,
                inactiveTrackColor = c.text.copy(alpha = 0.15f)
            )
        )
    }
}

@Composable
private fun PillButton(text: String, onClick: () -> Unit) {
    val c = LocalColors.current
    Box(
        Modifier.bounce(onClick = onClick).clip(RoundedCornerShape(16.dp)).background(c.accent)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) { Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun SettingsScreen(
    sims: List<SimAccount>,
    isDefault: Boolean,
    onRequestDefault: () -> Unit,
    onPickImage: () -> Unit,
    onImportPhotos: () -> Unit,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val settingsScroll = rememberScrollState()
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0"
    }
    var crash by remember { mutableStateOf(Prefs.lastCrash()) }

    val headerTop = statusBarTop() + 60.dp
    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().topScrollBlur(headerTop + 28.dp) { settingsScroll.scrollBlurStrength() }
                .verticalScroll(settingsScroll).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(Modifier.height(headerTop - 14.dp))
            SettingsCard(stringResource(R.string.default_dialer), 0) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(if (isDefault) R.string.status_yes else R.string.status_no),
                        color = if (isDefault) c.accent else c.sub, fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                    )
                    if (!isDefault) PillButton(stringResource(R.string.set_default), onRequestDefault)
                }
            }

            SettingsCard(stringResource(R.string.appearance), 1) {
                SubLabel(stringResource(R.string.theme_mode))
                ChipGroup(
                    listOf(
                        stringResource(R.string.mode_system) to ThemeMode.SYSTEM,
                        stringResource(R.string.mode_light) to ThemeMode.LIGHT,
                        stringResource(R.string.mode_dark) to ThemeMode.DARK
                    ),
                    Prefs.themeMode, 3
                ) { Prefs.updateThemeMode(it) }
                SwitchRow(stringResource(R.string.amoled), Prefs.amoled) { Prefs.updateAmoled(it) }
                SubLabel(stringResource(R.string.style))
                ChipGroup(
                    listOf(
                        stringResource(R.string.style_solid) to GlassStyle.SOLID,
                        stringResource(R.string.style_blur) to GlassStyle.BLUR,
                        stringResource(R.string.style_liquid) to GlassStyle.LIQUID
                    ),
                    Prefs.glass, 3
                ) {
                    Prefs.updateGlass(it)
                }
                if (Prefs.glass == GlassStyle.LIQUID) {
                    SliderRow(stringResource(R.string.liquid_strength), Prefs.liquid, 0, 100, "%") { Prefs.updateLiquid(it) }
                }
                SubLabel(stringResource(R.string.accent))
                val accents = Accent.values().filter { it != Accent.DYNAMIC || Build.VERSION.SDK_INT >= 31 }
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    accents.chunked(4).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            row.forEach { a ->
                                val dot = if (a == Accent.DYNAMIC) {
                                    Modifier.size(42.dp).bounce { Prefs.updateAccent(a) }.clip(CircleShape).background(
                                        Brush.sweepGradient(
                                            listOf(
                                                Color(0xFFEF4444), Color(0xFFF59E0B), Color(0xFF22C55E),
                                                Color(0xFF0EA5E9), Color(0xFF8B5CF6), Color(0xFFEF4444)
                                            )
                                        )
                                    )
                                } else {
                                    Modifier.size(42.dp).bounce { Prefs.updateAccent(a) }.clip(CircleShape)
                                        .background(Color(a.argb))
                                }
                                Box(dot, contentAlignment = Alignment.Center) {
                                    if (Prefs.accent == a) Icon(Ic.check, null, Modifier.size(22.dp), tint = Color.White)
                                }
                            }
                        }
                    }
                }
                SliderRow(stringResource(R.string.text_size), Prefs.textScale, 80, 130, "%") { Prefs.updateTextScale(it) }
            }

            SettingsCard(stringResource(R.string.backgrounds), 2) {
                SubLabel(stringResource(R.string.bg_mode))
                ChipGroup(
                    listOf(
                        stringResource(R.string.bg_solid) to AppBg.SOLID,
                        stringResource(R.string.bg_aurora) to AppBg.AURORA,
                        stringResource(R.string.bg_image) to AppBg.IMAGE
                    ),
                    Prefs.appBg, 3
                ) { Prefs.updateAppBg(it) }
                PillButton(stringResource(R.string.pick_image), onPickImage)
                if (Prefs.appBg == AppBg.IMAGE) {
                    SliderRow(stringResource(R.string.blur), Prefs.bgBlur, 0, 100) { Prefs.updateBgBlur(it) }
                    SliderRow(stringResource(R.string.dim), Prefs.bgDim, 0, 80, "%") { Prefs.updateBgDim(it) }
                }
            }

            SettingsCard(stringResource(R.string.call_screen), 3) {
                SubLabel(stringResource(R.string.call_bg))
                ChipGroup(
                    listOf(
                        stringResource(R.string.cbg_wallpaper) to CallBg.WALLPAPER,
                        stringResource(R.string.cbg_photo) to CallBg.PHOTO,
                        stringResource(R.string.cbg_aurora) to CallBg.AURORA,
                        stringResource(R.string.cbg_solid) to CallBg.SOLID
                    ),
                    Prefs.callBg, 2
                ) { Prefs.updateCallBg(it) }
                if (Prefs.callBg == CallBg.WALLPAPER) {
                    Text(stringResource(R.string.blur_unavailable), color = c.sub, fontSize = 12.sp)
                }
                if (Prefs.callBg == CallBg.WALLPAPER || Prefs.callBg == CallBg.PHOTO) {
                    SliderRow(stringResource(R.string.blur), Prefs.callBlur, 0, 100) { Prefs.updateCallBlur(it) }
                }
                SliderRow(stringResource(R.string.dim), Prefs.callDim, 0, 80, "%") { Prefs.updateCallDim(it) }
                SwitchRow(stringResource(R.string.show_avatar), Prefs.showAvatar) { Prefs.updateShowAvatar(it) }
            }

            SettingsCard(stringResource(R.string.dialpad_section), 4) {
                SubLabel(stringResource(R.string.key_style))
                ChipGroup(
                    listOf(
                        stringResource(R.string.key_plain) to KeyStyle.PLAIN,
                        stringResource(R.string.key_circle) to KeyStyle.CIRCLE
                    ),
                    Prefs.keyStyle, 2
                ) { Prefs.updateKeyStyle(it) }
                SwitchRow(stringResource(R.string.show_letters), Prefs.showLetters) { Prefs.updateShowLetters(it) }
                SwitchRow(stringResource(R.string.dtmf_tones), Prefs.tones) { Prefs.updateTones(it) }
                SwitchRow(stringResource(R.string.haptics), Prefs.haptics) { Prefs.updateHaptics(it) }
            }

            SettingsCard(stringResource(R.string.import_photos), 5) {
                Text(stringResource(R.string.import_photos_desc), color = c.sub, fontSize = 13.sp)
                PillButton(stringResource(R.string.import_photos_btn), onImportPhotos)
            }

            SettingsCard(stringResource(R.string.language), 5) {
                ChipGroup(
                    listOf(
                        stringResource(R.string.lang_system) to "",
                        "English" to "en",
                        "العربية" to "ar",
                        "Türkçe" to "tr"
                    ),
                    Prefs.lang, 2
                ) { Prefs.updateLang(it) }
            }

            SettingsCard(stringResource(R.string.calls_section), 6) {
                if (sims.size > 1) {
                    SubLabel(stringResource(R.string.default_sim))
                    ChipGroup(
                        listOf(
                            stringResource(R.string.sim_ask) to -1,
                            sims[0].label to 0,
                            sims[1].label to 1
                        ),
                        Prefs.defaultSim, 3
                    ) { Prefs.updateDefaultSim(it) }
                }
                Text(
                    stringResource(R.string.blocked_numbers), color = c.link, fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth().tap {
                        try {
                            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                            safeStart(ctx, tm.createManageBlockedNumbersIntent())
                        } catch (_: Throwable) {
                        }
                    }.padding(vertical = 6.dp)
                )
            }

            SettingsCard(stringResource(R.string.general), 7) {
                SwitchRow(stringResource(R.string.animations), Prefs.motion) { Prefs.updateMotion(it) }
            }

            SettingsCard(stringResource(R.string.about), 8) {
                Text(stringResource(R.string.app_name), color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(stringResource(R.string.version, version), color = c.sub, fontSize = 14.sp)
                Text(stringResource(R.string.made_by), color = c.sub, fontSize = 13.sp)
                Text(stringResource(R.string.about_privacy), color = c.sub, fontSize = 13.sp)
            }

            if (crash.isNotEmpty()) {
                SettingsCard(stringResource(R.string.crash_title), 9) {
                    Text(crash.take(500), color = c.sub, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        PillButton(stringResource(R.string.copy)) {
                            try {
                                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("crash", Prefs.lastCrash()))
                            } catch (_: Throwable) {
                            }
                        }
                        PillButton(stringResource(R.string.clear)) {
                            Prefs.clearCrash()
                            crash = ""
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
        Box(Modifier.statusBarsPadding()) { TopBar(stringResource(R.string.settings), onBack) }
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, modifier: Modifier) {
    val c = LocalColors.current
    Column(
        modifier.height(52.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, Modifier.size(22.dp), tint = c.text)
        Text(label, color = c.text, fontSize = 11.sp, maxLines = 1, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun BottomNav(tab: Int, onTab: (Int) -> Unit, padOpen: Boolean, onProgress: (Float) -> Unit, onPad: () -> Unit) {
    val c = LocalColors.current
    val density = LocalDensity.current
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val itemWidth = 88.dp
    val itemWidthPx = with(density) { itemWidth.toPx() }
    val capsule = remember { Animatable(tab * itemWidthPx) }
    var pressed by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    // 0..1: how much the capsule is stretched by its own speed (the "liquid" feel of the reference video)
    var stretch by remember { mutableStateOf(0f) }
    val scope = rememberCoroutineScope()
    val latestTab by rememberUpdatedState(tab)
    val latestOnTab by rememberUpdatedState(onTab)
    val latestProgress by rememberUpdatedState(onProgress)

    // Press / release: ~240 ms ease-out (measured on the reference video).
    val easeOut = remember { androidx.compose.animation.core.CubicBezierEasing(0.2f, 0.6f, 0.2f, 1f) }
    val press by animateFloatAsState(if (pressed) 1f else 0f, tween(240, easing = easeOut), label = "press")
    // Gliding between tabs: starts gently, travels, then settles slowly (no bounce).
    val glide = remember {
        tween<Float>(440, easing = androidx.compose.animation.core.CubicBezierEasing(0.4f, 0f, 0.2f, 1f))
    }

    // The capsule stretches along its direction of travel proportionally to its speed and relaxes when it
    // slows down: fast attack (~25 ms), slower release (~65 ms), like in the video.
    LaunchedEffect(itemWidthPx) {
        var last = capsule.value
        var lastT = 0L
        while (true) {
            if (stretch == 0f && !capsule.isRunning && !dragging) {
                // nothing is moving: stop asking for frames until the capsule starts to move again
                androidx.compose.runtime.snapshotFlow { capsule.isRunning || dragging }
                    .first { it }
                last = capsule.value
                lastT = 0L
            }
            val t = withFrameNanos { it }
            if (lastT != 0L) {
                val dt = ((t - lastT) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
                val v = (capsule.value - last) / dt
                val target = (abs(v) / (itemWidthPx * 4.5f)).coerceIn(0f, 1f)
                val tau = if (target > stretch) 0.025f else 0.065f
                val next = stretch + (target - stretch) * (1f - kotlin.math.exp(-dt / tau))
                stretch = if (abs(next) < 0.002f && target == 0f) 0f else next
            }
            last = capsule.value
            lastT = t
        }
    }

    // Tells the screen how far the capsule is between the two tabs, so the page moves with it (no waiting).
    LaunchedEffect(itemWidthPx) {
        androidx.compose.runtime.snapshotFlow { capsule.value / itemWidthPx }
            .collect { latestProgress(it.coerceIn(0f, 1f)) }
    }

    // Follows the selected tab (also when it changes from elsewhere), unless the finger is dragging it.
    LaunchedEffect(tab) {
        if (!dragging) capsule.animateTo(tab * itemWidthPx, glide)
    }

    // Forced LTR: raw pixel offsets don't mirror, but Row child order does under RTL locales
    // (Arabic) — without this the capsule would land on the wrong physical side.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box {
          // the glass panel is its own layer: the moving capsule never forces it to re-render the blur / lens
          Box(Modifier.matchParentSize().glass(RoundedCornerShape(32.dp)))
          Box(Modifier.padding(5.dp)) {
            Box(
                Modifier.pointerInput(itemWidthPx) {
                    // Tap an item, or press and slide the capsule; it settles on the nearest tab when released.
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        pressed = true
                        val startX = down.position.x
                        val grab = (startX - (capsule.value + itemWidthPx / 2f)).coerceIn(-itemWidthPx / 2f, itemWidthPx / 2f)
                        val slop = viewConfiguration.touchSlop
                        var moved = false
                        var lastSide = if (capsule.value + itemWidthPx / 2f > itemWidthPx) 1 else 0
                        while (true) {
                            val event = awaitPointerEvent()
                            val ch = event.changes.firstOrNull { it.id == down.id } ?: break
                            if (!ch.pressed) {
                                ch.consume()
                                break
                            }
                            val x = ch.position.x
                            if (!moved && abs(x - startX) > slop) {
                                moved = true
                                dragging = true
                            }
                            if (moved) {
                                ch.consume()
                                val target = (x - grab - itemWidthPx / 2f).coerceIn(-itemWidthPx * 0.08f, itemWidthPx * 1.08f)
                                scope.launch { capsule.snapTo(target) }
                                // light tick when the capsule crosses into the other tab
                                val side = if (target + itemWidthPx / 2f > itemWidthPx) 1 else 0
                                if (side != lastSide) {
                                    lastSide = side
                                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                }
                            }
                        }
                        val newTab = if (moved) ((capsule.value + itemWidthPx / 2f) / itemWidthPx).toInt().coerceIn(0, 1)
                        else (startX / itemWidthPx).toInt().coerceIn(0, 1)
                        dragging = false
                        // keep the "held" look for a moment on a plain tap so the press is visible
                        scope.launch {
                            if (!moved) kotlinx.coroutines.delay(140)
                            pressed = false
                        }
                        if (newTab != latestTab) {
                            if (!moved) haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                            // the capsule glides to its new tab from the effect below; the page follows it
                            latestOnTab(newTab)
                        } else {
                            scope.launch { capsule.animateTo(newTab * itemWidthPx, glide) }
                        }
                    }
                }
            ) {
                // Same capsule in both states; only its layering changes:
                // resting = solid, behind the icons; held = shrunk, lighter and translucent, over them.
                @Composable
                fun capsuleShape(color: Color) {
                    val extraOf = { itemWidthPx * 0.25f * stretch }
                    Box(
                        Modifier
                            .absoluteOffset {
                                IntOffset((capsule.value + 2.dp.toPx() - extraOf() / 2f).roundToInt(), 2.dp.roundToPx())
                            }
                            .layout { measurable, _ ->
                                val w = (itemWidth - 4.dp).roundToPx() + extraOf().roundToInt()
                                val h = 48.dp.roundToPx()
                                val pl = measurable.measure(androidx.compose.ui.unit.Constraints.fixed(w, h))
                                layout(w, h) { pl.place(0, 0) }
                            }
                            .graphicsLayer {
                                scaleX = 1f - 0.07f * press
                                scaleY = 1f - 0.10f * press
                            }
                            .clip(CircleShape)
                            .background(color)
                    )
                }
                capsuleShape(c.text.copy(alpha = 0.13f * (1f - press)))
                Row {
                    NavItem(CallIc.navRecents, stringResource(R.string.recents), Modifier.width(itemWidth))
                    NavItem(CallIc.navContacts, stringResource(R.string.contacts), Modifier.width(itemWidth))
                }
                capsuleShape(c.sub.copy(alpha = 0.55f * press))
            }
          }
        }
        Box(
            Modifier.size(58.dp).bounce(onClick = onPad).then(
                if (padOpen && tab != 1) Modifier.glass(CircleShape) else Modifier.clip(CircleShape).background(c.accent)
            ),
            contentAlignment = Alignment.Center
        ) {
            // contacts tab: the round button adds a contact; otherwise it toggles the dial pad
            // Every state is drawn in the same fixed 32dp slot, so the icon never shifts while it cross-fades.
            Crossfade(targetState = if (tab == 1) 2 else if (padOpen) 1 else 0, animationSpec = tween(260), label = "fab") { st ->
                Box(Modifier.size(32.dp), contentAlignment = Alignment.Center) {
                    Icon(
                        when (st) {
                            2 -> Ic.add
                            1 -> Ic.keyboardDown
                            else -> Ic.dialpad
                        },
                        null, Modifier.size(if (st == 2) 32.dp else 26.dp),
                        tint = if (st == 1) c.text else Color.White
                    )
                }
            }
        }
    }
    }
}

/** Small confirmation dialog in the app's glass style. */
@Composable
fun ConfirmDialog(message: String, confirmLabel: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val c = LocalColors.current
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(c.surfaceHigh).padding(22.dp)
        ) {
            Text(message, color = c.text, fontSize = 18.sp)
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Text(
                    stringResource(R.string.cancel), color = c.sub, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.tap(onClick = onDismiss).padding(horizontal = 14.dp, vertical = 10.dp)
                )
                Text(
                    confirmLabel, color = c.danger, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.tap(onClick = onConfirm).padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }
        }
    }
}


/** In-app "new contact" screen (same visual language as the contact details screen). */
@Composable
fun AddContactScreen(
    initialNumber: String,
    onBack: () -> Unit,
    onSave: (first: String, last: String, number: String, note: String) -> Unit
) {
    val c = LocalColors.current
    var first by rememberSaveable { mutableStateOf("") }
    var last by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf(initialNumber) }
    var note by rememberSaveable { mutableStateOf("") }
    val canSave = phone.any { it.isDigit() } && (first.isNotBlank() || last.isNotBlank())
    val addScroll = rememberScrollState()
    val ctxAdd = LocalContext.current

    @Composable
    fun Field(value: String, hint: String, onChange: (String) -> Unit, type: androidx.compose.ui.text.input.KeyboardType) {
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = c.text, fontSize = 18.sp),
            cursorBrush = SolidColor(c.accent),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = type),
            decorationBox = { inner ->
                Box(Modifier.fillMaxWidth().height(58.dp), contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Text(hint, color = c.sub, fontSize = 18.sp)
                    inner()
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
    }

    @Composable
    fun Divider() {
        Box(Modifier.fillMaxWidth().height(1.dp).background(c.sub.copy(alpha = 0.15f)))
    }

    val headerTop = statusBarTop() + 60.dp
    Box(Modifier.fillMaxSize().imePadding()) {
        Column(
            Modifier.fillMaxSize().topScrollBlur(headerTop + 28.dp) { addScroll.scrollBlurStrength() }
                .verticalScroll(addScroll).padding(horizontal = 14.dp)
        ) {
            Spacer(Modifier.height(headerTop))
            Column(
                Modifier.fillMaxWidth().enterAnim(0).padding(top = 20.dp, bottom = 30.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Avatar(null, null, 124.dp)
                Spacer(Modifier.height(26.dp))
                Text(
                    stringResource(R.string.new_contact), color = c.text, fontSize = 34.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
            Column(Modifier.fillMaxWidth().enterAnim(1).glass(RoundedCornerShape(28.dp)).padding(horizontal = 20.dp)) {
                Field(first, stringResource(R.string.first_name), { first = it }, androidx.compose.ui.text.input.KeyboardType.Text)
                Divider()
                Field(last, stringResource(R.string.last_name), { last = it }, androidx.compose.ui.text.input.KeyboardType.Text)
                Divider()
                Field(phone, stringResource(R.string.phone_number), { phone = it }, androidx.compose.ui.text.input.KeyboardType.Phone)
                Divider()
                Field(note, stringResource(R.string.note), { note = it }, androidx.compose.ui.text.input.KeyboardType.Text)
            }
            Spacer(Modifier.height(24.dp))
            Box(
                Modifier.fillMaxWidth().enterAnim(2).height(56.dp).clip(CircleShape)
                    .background(if (canSave) c.accent else c.sub.copy(alpha = 0.45f))
                    .tap {
                        if (canSave) onSave(first, last, phone, note)
                        else android.widget.Toast.makeText(ctxAdd, R.string.add_contact_hint, android.widget.Toast.LENGTH_SHORT).show()
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(stringResource(R.string.save), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(40.dp))
        }
        FloatingBack(onBack)
    }
}


/** Round back button that floats over the content (the content scrolls and blurs under it). */
@Composable
private fun FloatingBack(onBack: () -> Unit) {
    val c = LocalColors.current
    Box(
        Modifier.statusBarsPadding().padding(start = 12.dp, top = 8.dp).size(44.dp).clip(CircleShape)
            .background(c.text.copy(alpha = 0.10f)).tap(onClick = onBack),
        contentAlignment = Alignment.Center
    ) { Icon(Ic.back, null, tint = c.text) }
}

package app.glassdialer

import android.app.Application

class DialerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                Prefs.saveCrash(e.stackTraceToString().take(6000))
            } catch (_: Throwable) {
            }
            old?.uncaughtException(t, e)
        }
    }
}

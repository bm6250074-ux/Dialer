package app.glassdialer.call

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.core.app.NotificationCompat
import app.glassdialer.R
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Foreground (microphone) service that records the current call to an .m4a file and publishes it
 * to the shared Recordings folder. It tries the call-audio source first (captures both sides on
 * devices that allow it) and falls back to communication / microphone sources otherwise.
 */
class CallRecordService : Service() {
    private var recorder: MediaRecorder? = null
    private var tmp: File? = null
    private var label = ""
    private var source = -1
    private val main = Handler(Looper.getMainLooper())
    private val silenceCheck = Runnable { checkSilence() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        CallRecorder.service = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> finishRecording()
            else -> {
                label = intent?.getStringExtra(EXTRA_LABEL).orEmpty()
                beginRecording()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        main.removeCallbacks(silenceCheck)
        releaseQuietly()
        if (CallRecorder.service === this) CallRecorder.service = null
        CallRecorder._state.value = CallRecorder.State()
        super.onDestroy()
    }

    private fun beginRecording() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH_ACTIVE, getString(R.string.recording), NotificationManager.IMPORTANCE_LOW)
                    .apply { setShowBadge(false) }
            )
        }
        try {
            val n = activeNotification()
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(ID_ACTIVE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(ID_ACTIVE, n)
            }
        } catch (_: Throwable) {
            fail()
            return
        }

        val dir = File(cacheDir, "rec").apply { mkdirs() }
        val file = File(dir, "rec_${System.currentTimeMillis()}.m4a")
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_CALL,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.MIC
        )
        for (src in sources) {
            val r = newRecorder()
            try {
                r.setAudioSource(src)
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioChannels(1)
                r.setAudioSamplingRate(44100)
                r.setAudioEncodingBitRate(96000)
                r.setOutputFile(file.absolutePath)
                r.prepare()
                r.start()
                recorder = r
                source = src
                break
            } catch (_: Throwable) {
                try { r.release() } catch (_: Throwable) { }
            }
        }
        if (recorder == null) {
            file.delete()
            fail()
            return
        }
        tmp = file
        CallRecorder._state.value = CallRecorder.State(true, System.currentTimeMillis())
        if (source != MediaRecorder.AudioSource.VOICE_CALL) {
            toast(this, R.string.record_hint_mic)
            main.postDelayed(silenceCheck, 7000)
        }
    }

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun checkSilence() {
        val r = recorder ?: return
        val peak = try { r.maxAmplitude } catch (_: Throwable) { 1 }
        if (peak <= 0) toast(this, R.string.record_silent)
    }

    private fun fail() {
        toast(this, R.string.record_failed)
        CallRecorder._state.value = CallRecorder.State()
        stopForegroundCompat()
        stopSelf()
    }

    /** Stops, saves the file to the shared Recordings folder and tells the user. */
    fun finishRecording() {
        main.removeCallbacks(silenceCheck)
        val r = recorder
        val file = tmp
        recorder = null
        tmp = null
        var ok = r != null && file != null
        if (r != null) {
            try { r.stop() } catch (_: Throwable) { ok = false }
            try { r.release() } catch (_: Throwable) { }
        }
        CallRecorder._state.value = CallRecorder.State()
        if (ok && file != null && file.length() > 1024) {
            val uri = publish(file)
            file.delete()
            if (uri != null || Build.VERSION.SDK_INT < 29) notifySaved(uri)
        } else {
            file?.delete()
        }
        stopForegroundCompat()
        stopSelf()
    }

    private fun releaseQuietly() {
        try { recorder?.stop() } catch (_: Throwable) { }
        try { recorder?.release() } catch (_: Throwable) { }
        recorder = null
        tmp?.delete()
        tmp = null
    }

    @Suppress("DEPRECATION")
    private fun stopForegroundCompat() {
        try {
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        } catch (_: Throwable) { }
    }

    private fun fileName(): String {
        val safe = label.replace(Regex("[^\\p{L}\\p{N}+ _-]"), "").trim().replace(' ', '_').ifEmpty { "Call" }
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return "Call_${safe}_$ts.m4a"
    }

    /** Copies the temp file to MediaStore (Android 10+) or the app's Music folder (older). */
    private fun publish(file: File): Uri? {
        val name = fileName()
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, name)
                    put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                    put(
                        MediaStore.Audio.Media.RELATIVE_PATH,
                        if (Build.VERSION.SDK_INT >= 31) "Recordings/GlassDialer" else "Music/GlassDialer"
                    )
                    put(MediaStore.Audio.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
                contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                cv.clear()
                cv.put(MediaStore.Audio.Media.IS_PENDING, 0)
                contentResolver.update(uri, cv, null, null)
                uri
            } else {
                val dir = File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "GlassDialer").apply { mkdirs() }
                file.copyTo(File(dir, name), overwrite = true)
                null
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun activeNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stop = PendingIntent.getService(
            this, 11, Intent(this, CallRecordService::class.java).setAction(ACTION_STOP), flags
        )
        return NotificationCompat.Builder(this, CH_ACTIVE)
            .setSmallIcon(R.drawable.ic_call)
            .setContentTitle(getString(R.string.recording))
            .setContentText(label)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setUsesChronometer(true)
            .addAction(0, getString(R.string.stop_recording), stop)
            .build()
    }

    private fun notifySaved(uri: Uri?) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH_SAVED, getString(R.string.recording_saved), NotificationManager.IMPORTANCE_DEFAULT)
                    .apply { setShowBadge(false) }
            )
        }
        val b = NotificationCompat.Builder(this, CH_SAVED)
            .setSmallIcon(R.drawable.ic_call)
            .setContentTitle(getString(R.string.recording_saved))
            .setContentText(label)
            .setAutoCancel(true)
        if (uri != null) {
            val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "audio/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            b.setContentIntent(
                PendingIntent.getActivity(this, 12, view, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            )
        }
        try {
            nm.notify(ID_SAVED + (System.currentTimeMillis() % 1000).toInt(), b.build())
        } catch (_: SecurityException) { }
    }

    companion object {
        const val ACTION_START = "app.glassdialer.REC_START"
        const val ACTION_STOP = "app.glassdialer.REC_STOP"
        const val EXTRA_LABEL = "label"
        private const val CH_ACTIVE = "recording_active"
        private const val CH_SAVED = "recording_saved"
        private const val ID_ACTIVE = 4201
        private const val ID_SAVED = 4300

        fun toast(ctx: Context, @StringRes res: Int) {
            Handler(Looper.getMainLooper()).post { Toast.makeText(ctx.applicationContext, res, Toast.LENGTH_LONG).show() }
        }
    }
}

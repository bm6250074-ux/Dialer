package app.glassdialer.call

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.core.app.NotificationCompat
import app.glassdialer.Prefs
import app.glassdialer.R
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import kotlin.math.abs
import kotlin.math.tanh

/**
 * Foreground (microphone) service that records the call with [AudioRecord] as raw 16-bit PCM, applies a
 * soft-clipped gain on every buffer and stores it as a WAV file in Android/data/<package>/files/CallRecordings.
 *
 * Source order: call audio (both sides, only where the phone allows it), then recognition / microphone /
 * communication sources. With the microphone sources the other person is only audible when the speaker is on.
 */
class CallRecordService : Service() {
    private var audio: AudioRecord? = null
    private var worker: Thread? = null
    @Volatile private var running = false
    private var file: File? = null
    private var label = ""
    private var number = ""
    private var source = -1
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        CallRecorder.service = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> finishRecording()
            else -> {
                label = intent?.getStringExtra(EXTRA_LABEL).orEmpty()
                number = intent?.getStringExtra(EXTRA_NUMBER).orEmpty()
                beginRecording()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        try { worker?.join(1500) } catch (_: Throwable) { }
        releaseAudio()
        if (CallRecorder.service === this) CallRecorder.service = null
        CallRecorder._state.value = CallRecorder.State()
        super.onDestroy()
    }

    private fun beginRecording() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH_ACTIVE, getString(R.string.recording), NotificationManager.IMPORTANCE_LOW)
                    .apply { setShowBadge(false) }
            )
        }
        try {
            val n = activeNotification()
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(ID_ACTIVE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(ID_ACTIVE, n)
            }
        } catch (_: Throwable) {
            fail()
            return
        }

        val rate = SAMPLE_RATE
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufSize = maxOf(if (min > 0) min * 2 else 0, 8192)
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_CALL,
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION
        )
        var rec: AudioRecord? = null
        for (src in sources) {
            try {
                val r = AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize)
                if (r.state != AudioRecord.STATE_INITIALIZED) {
                    r.release()
                    continue
                }
                r.startRecording()
                if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                    r.release()
                    continue
                }
                rec = r
                source = src
                break
            } catch (_: Throwable) {
            }
        }
        if (rec == null) {
            fail()
            return
        }
        val startMs = System.currentTimeMillis()
        val out = Recordings.newFile(this, startMs, number)
        audio = rec
        file = out
        running = true
        CallRecorder._state.value = CallRecorder.State(true, startMs)
        if (source != MediaRecorder.AudioSource.VOICE_CALL) toast(this, R.string.record_hint_mic)
        val a = rec
        val bufShorts = bufSize / 2
        worker = Thread({ captureLoop(a, out, bufShorts) }, "call-recorder").also { it.start() }
    }

    /** Reads PCM, applies gain, writes the WAV. Runs on its own thread. */
    private fun captureLoop(a: AudioRecord, out: File, bufShorts: Int) {
        val gain = Prefs.recGain.coerceIn(1, 10).toFloat()
        val shorts = ShortArray(bufShorts)
        val bytes = ByteArray(bufShorts * 2)
        var total = 0L
        var rawPeak = 0
        var warned = false
        val t0 = System.currentTimeMillis()
        try {
            BufferedOutputStream(FileOutputStream(out), 64 * 1024).use { os ->
                os.write(ByteArray(WAV_HEADER))
                while (running) {
                    val n = a.read(shorts, 0, shorts.size)
                    if (n < 0) break
                    if (n == 0) continue
                    var j = 0
                    for (i in 0 until n) {
                        val s = shorts[i].toInt()
                        val m = abs(s)
                        if (m > rawPeak) rawPeak = m
                        val v = softGain(s / 32768f, gain)
                        val o = (v * 32767f).toInt().coerceIn(-32768, 32767)
                        bytes[j++] = (o and 0xFF).toByte()
                        bytes[j++] = ((o shr 8) and 0xFF).toByte()
                    }
                    os.write(bytes, 0, j)
                    total += j
                    if (!warned && System.currentTimeMillis() - t0 > 7000 && rawPeak == 0) {
                        warned = true
                        toast(this, R.string.record_silent)
                    }
                }
                os.flush()
            }
            writeWavHeader(out, total)
        } catch (_: Throwable) {
        }
    }

    /** Linear gain with a soft knee: no harsh clipping when the amplified peaks go over full scale. */
    private fun softGain(x: Float, g: Float): Float {
        val y = x * g
        val knee = 0.7f
        val ay = abs(y)
        if (ay <= knee) return y
        val s = knee + (1f - knee) * tanh((ay - knee) / (1f - knee))
        return if (y < 0) -s else s
    }

    private fun writeWavHeader(f: File, dataLen: Long) {
        RandomAccessFile(f, "rw").use { raf ->
            val h = java.nio.ByteBuffer.allocate(WAV_HEADER).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt((36 + dataLen).toInt())
            h.put("WAVE".toByteArray()); h.put("fmt ".toByteArray()); h.putInt(16)
            h.putShort(1); h.putShort(1); h.putInt(SAMPLE_RATE); h.putInt(SAMPLE_RATE * 2)
            h.putShort(2); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(dataLen.toInt())
            raf.seek(0)
            raf.write(h.array())
        }
    }

    private fun fail() {
        toast(this, R.string.record_failed)
        CallRecorder._state.value = CallRecorder.State()
        stopForegroundCompat()
        stopSelf()
    }

    /** Stops the capture; the WAV stays in the app folder and shows up next to the call in Recents. */
    fun finishRecording() {
        if (!running && audio == null) {
            stopForegroundCompat()
            stopSelf()
            return
        }
        running = false
        try { worker?.join(2000) } catch (_: Throwable) { }
        worker = null
        releaseAudio()
        val f = file
        file = null
        CallRecorder._state.value = CallRecorder.State()
        if (f != null && f.length() > 1024 + WAV_HEADER) {
            toast(this, R.string.recording_saved)
        } else {
            f?.delete()
        }
        Recordings.version.value++
        stopForegroundCompat()
        stopSelf()
    }

    private fun releaseAudio() {
        try { audio?.stop() } catch (_: Throwable) { }
        try { audio?.release() } catch (_: Throwable) { }
        audio = null
    }

    @Suppress("DEPRECATION")
    private fun stopForegroundCompat() {
        try {
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        } catch (_: Throwable) { }
    }

    private fun activeNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stop = PendingIntent.getService(
            this, 11, Intent(this, CallRecordService::class.java).setAction(ACTION_STOP), flags
        )
        return NotificationCompat.Builder(this, CH_ACTIVE)
            .setSmallIcon(R.drawable.ic_call)
            .setContentTitle(getString(R.string.recording))
            .setContentText(label)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setUsesChronometer(true)
            .addAction(0, getString(R.string.stop_recording), stop)
            .build()
    }

    companion object {
        const val ACTION_START = "app.glassdialer.REC_START"
        const val ACTION_STOP = "app.glassdialer.REC_STOP"
        const val EXTRA_LABEL = "label"
        const val EXTRA_NUMBER = "number"
        private const val CH_ACTIVE = "recording_active"
        private const val ID_ACTIVE = 4201
        private const val SAMPLE_RATE = 16000
        private const val WAV_HEADER = 44

        fun toast(ctx: Context, @StringRes res: Int) {
            Handler(Looper.getMainLooper()).post { Toast.makeText(ctx.applicationContext, res, Toast.LENGTH_LONG).show() }
        }
    }
}

package app.glassdialer.call

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import app.glassdialer.Repo
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

/**
 * Recordings live in the app's private external folder (Android/data/<package>/files/CallRecordings).
 * File name: rec_<startMillis>_<last9digits>.wav
 */
object Recordings {
    class Rec(val file: File, val startMs: Long, val num: String)

    /** Bumped whenever a recording is added or removed so the UI can refresh. */
    val version = MutableStateFlow(0)

    private val NAME = Regex("rec_(\\d+)_(\\d+)\\.wav")

    fun dir(ctx: Context): File =
        (ctx.getExternalFilesDir("CallRecordings") ?: File(ctx.filesDir, "CallRecordings")).apply { mkdirs() }

    private fun key(number: String): String = Repo.norm(number).ifEmpty { "0" }

    fun newFile(ctx: Context, startMs: Long, number: String): File =
        File(dir(ctx), "rec_${startMs}_${key(number)}.wav")

    fun list(ctx: Context): List<Rec> =
        dir(ctx).listFiles()?.mapNotNull { f ->
            val m = NAME.matchEntire(f.name) ?: return@mapNotNull null
            if (f.length() <= 1024) null else Rec(f, m.groupValues[1].toLong(), m.groupValues[2])
        }?.sortedByDescending { it.startMs } ?: emptyList()

    /** Finds the recording that belongs to a call-log entry (same number, started during that call). */
    fun match(recs: List<Rec>, number: String, date: Long, durationSec: Long): Rec? {
        if (recs.isEmpty()) return null
        val k = key(number)
        return recs.firstOrNull { it.num == k && it.startMs >= date - 10_000 && it.startMs <= date + durationSec * 1000 + 180_000 }
    }

    fun delete(rec: Rec): Boolean {
        val ok = rec.file.delete()
        version.value++
        return ok
    }

    /** Copies the recording to Downloads/IN-Phone (Android 10+). */
    fun saveToDownloads(ctx: Context, rec: Rec): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, rec.file.name)
                put(MediaStore.Downloads.MIME_TYPE, "audio/wav")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/IN-Phone")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return false
            ctx.contentResolver.openOutputStream(uri)?.use { out -> rec.file.inputStream().use { it.copyTo(out) } }
            cv.clear()
            cv.put(MediaStore.Downloads.IS_PENDING, 0)
            ctx.contentResolver.update(uri, cv, null, null)
            true
        } catch (_: Throwable) {
            false
        }
    }
}

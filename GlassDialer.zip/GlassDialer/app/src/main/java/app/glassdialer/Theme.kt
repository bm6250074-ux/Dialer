package app.glassdialer

import android.app.Activity
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

class AppColors(
    val dark: Boolean,
    val bg: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val text: Color,
    val sub: Color,
    val accent: Color,
    val link: Color,
    val danger: Color
)

val LocalColors = staticCompositionLocalOf<AppColors> { error("AppTheme missing") }
val LocalGlass = staticCompositionLocalOf { GlassStyle.SOLID }
/** The app's recorded background, so "Blur" panels can sample and blur what's actually behind them. */
val LocalBackdrop = staticCompositionLocalOf<GraphicsLayer?> { null }
/**
 * The screen content (lists) that sits *behind* floating panels such as the bottom bar and the
 * dial pad. Only provided to those floating panels — never to panels inside the recorded content
 * itself, which would make a layer draw itself.
 */
val LocalContentBackdrop = staticCompositionLocalOf<GraphicsLayer?> { null }

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = when (Prefs.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val amoled = Prefs.amoled
    val accent = if (Prefs.accent == Accent.DYNAMIC && Build.VERSION.SDK_INT >= 31) {
        Color(ctx.getColor(android.R.color.system_accent1_500))
    } else Color(Prefs.accent.argb)

    val colors = remember(dark, accent, amoled) {
        if (dark) {
            if (amoled) AppColors(
                true, Color(0xFF000000), Color(0xFF2A2A2C), Color(0xFF3A3A3D), Color(0xFFFFFFFF),
                Color(0xFF9A9AA0), accent, Color(0xFF4C8DFF), Color(0xFFE5342F)
            ) else AppColors(
                true, Color(0xFF16161A), Color(0xFF26262B), Color(0xFF34343A), Color(0xFFFFFFFF),
                Color(0xFFA0A0A8), accent, Color(0xFF4C8DFF), Color(0xFFE5342F)
            )
        } else AppColors(
            false, Color(0xFFF2F2F7), Color(0xFFFFFFFF), Color(0xFFE9E9EE), Color(0xFF111114),
            Color(0xFF6B6B73), accent, Color(0xFF2563EB), Color(0xFFD92D20)
        )
    }
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val ctl = WindowCompat.getInsetsController(w, view)
            ctl.isAppearanceLightStatusBars = !dark
            ctl.isAppearanceLightNavigationBars = !dark
        }
    }
    val d = LocalDensity.current
    val scale = Prefs.textScale
    val dens = remember(d, scale) { Density(d.density, d.fontScale * (scale / 100f)) }
    CompositionLocalProvider(
        LocalDensity provides dens,
        LocalColors provides colors,
        LocalGlass provides Prefs.glass,
        LocalContentColor provides colors.text
    ) { content() }
}

fun DrawScope.blob(color: Color, cx: Float, cy: Float, r: Float) {
    drawCircle(
        brush = Brush.radialGradient(listOf(color, Color.Transparent), center = Offset(cx, cy), radius = r),
        radius = r,
        center = Offset(cx, cy)
    )
}

fun DrawScope.drawAurora(area: Size, ph: Float, colors: List<Color>, alpha: Float) {
    val w = area.width
    val h = area.height
    colors.forEachIndexed { i, col ->
        val off = i * 1.7f
        val ky = 1 + (i % 2)
        val cx = w * (0.5f + 0.45f * cos(ph + off))
        val cy = h * (0.5f + 0.40f * sin(ph * ky + off))
        blob(col.copy(alpha = alpha), cx, cy, w * (0.7f + 0.08f * i))
    }
}

/** Slowly drifting colour blobs (used by the call screen and as an optional app background). */
@Composable
fun Aurora(colors: List<Color>, alpha: Float, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "aurora")
    val p by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(26000, easing = LinearEasing), RepeatMode.Restart),
        label = "p"
    )
    val motion = Prefs.motion
    Canvas(modifier.fillMaxSize()) {
        val ph = if (motion) p * 2f * PI.toFloat() else 0.8f
        drawAurora(size, ph, colors, alpha)
    }
}

private fun DrawScope.drawCropped(img: ImageBitmap, area: Size, dim: Float) {
    val iw = img.width.toFloat()
    val ih = img.height.toFloat()
    val sc = max(area.width / iw, area.height / ih)
    val dw = iw * sc
    val dh = ih * sc
    val dx = (area.width - dw) / 2f
    val dy = (area.height - dh) / 2f
    drawImage(
        image = img,
        dstOffset = IntOffset(dx.roundToInt(), dy.roundToInt()),
        dstSize = IntSize(dw.roundToInt(), dh.roundToInt()),
        filterQuality = FilterQuality.High
    )
    if (dim > 0f) drawRect(Color.Black.copy(alpha = dim), size = area)
}

/**
 * The app's background: a plain colour, slow drifting colour blobs, or a (pre-blurred, drawn
 * once) picture — recorded into a shared layer so "Blur" panels elsewhere on screen can sample
 * and blur the real thing behind them, instead of faking it with a flat tint.
 */
@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    val ctx = LocalContext.current
    val c = LocalColors.current
    val mode = Prefs.appBg
    val uri = Prefs.bgImage
    val blur = Prefs.bgBlur
    val dimPct = Prefs.bgDim
    val img by produceState<ImageBitmap?>(null, mode, uri, blur) {
        value = if (mode == AppBg.IMAGE && uri.isNotEmpty()) {
            val b = loadBackground(ctx, uri)
            if (b != null) withContext(Dispatchers.Default) { blurBitmap(b, blur).asImageBitmap() } else null
        } else null
    }
    val backdropLayer = rememberGraphicsLayer()
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxSize()
                .background(c.bg)
                .drawWithContent {
                    backdropLayer.record { this@drawWithContent.drawContent() }
                    drawLayer(backdropLayer)
                }
        ) {
            when (mode) {
                AppBg.SOLID -> {}
                AppBg.AURORA -> Aurora(
                    listOf(c.accent, Color(0xFF7C3AED), Color(0xFF0EA5E9), Color(0xFFEC4899)),
                    if (c.dark) 0.34f else 0.42f
                )
                AppBg.IMAGE -> {
                    val i = img
                    if (i != null) {
                        Canvas(Modifier.fillMaxSize()) { drawCropped(i, size, dimPct / 100f) }
                    }
                }
            }
        }
        CompositionLocalProvider(LocalBackdrop provides backdropLayer) {
            content()
        }
    }
}

/**
 * The one surface modifier used throughout the app.
 *  - Solid : plain opaque surface.
 *  - Blur  : a real backdrop blur of whatever is actually behind the panel (Android 12+, falls
 *            back to a translucent tint on older devices or if the backdrop isn't available).
 *  - Liquid: a translucent tint plus a slow moving highlight, evoking light flowing over glass.
 */
fun Modifier.glass(shape: Shape = RoundedCornerShape(28.dp)): Modifier = composed {
    val c = LocalColors.current
    val style = LocalGlass.current.let { if (it == GlassStyle.LIQUID && Build.VERSION.SDK_INT < 31) GlassStyle.BLUR else it }
    when (style) {
        GlassStyle.SOLID -> this.clip(shape).background(c.surface)

        GlassStyle.BLUR -> {
            val backdrop = LocalBackdrop.current
            val contentBackdrop = LocalContentBackdrop.current
            if (backdrop != null && Build.VERSION.SDK_INT >= 31) {
                val panelLayer = rememberGraphicsLayer()
                val pos = remember { mutableStateOf(Offset.Zero) }
                this
                    .onGloballyPositioned { pos.value = it.positionInRoot() }
                    .clip(shape)
                    .drawWithContent {
                        val p = pos.value
                        // Record a margin around the panel too, so the heavy blur at the panel's edges
                        // mixes in the real surroundings instead of repeating/smearing the edge pixels.
                        val pad = 180
                        panelLayer.record(
                            size = IntSize(size.width.toInt() + 2 * pad, size.height.toInt() + 2 * pad)
                        ) {
                            translate(pad - p.x, pad - p.y) {
                                drawLayer(backdrop)
                                if (contentBackdrop != null) drawLayer(contentBackdrop)
                            }
                        }
                        panelLayer.renderEffect =
                            RenderEffect.createBlurEffect(90f, 90f, Shader.TileMode.CLAMP).asComposeRenderEffect()
                        translate(-pad.toFloat(), -pad.toFloat()) { drawLayer(panelLayer) }
                        drawContent()
                    }
                    .background(
                        Brush.verticalGradient(
                            if (c.dark) listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.05f))
                            else listOf(Color.White.copy(alpha = 0.34f), Color.White.copy(alpha = 0.16f))
                        )
                    )
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(Color.White.copy(alpha = if (c.dark) 0.32f else 0.9f), Color.White.copy(alpha = 0.05f))
                        ),
                        shape
                    )
            } else {
                this.clip(shape)
                    .background(
                        Brush.verticalGradient(
                            if (c.dark) listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.07f))
                            else listOf(Color.White.copy(alpha = 0.68f), Color.White.copy(alpha = 0.42f))
                        )
                    )
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(Color.White.copy(alpha = if (c.dark) 0.32f else 0.9f), Color.White.copy(alpha = 0.05f))
                        ),
                        shape
                    )
            }
        }

        GlassStyle.LIQUID -> {
            val backdrop = LocalBackdrop.current
            val contentBackdrop = LocalContentBackdrop.current
            val strength = Prefs.liquid / 100f
            val lens = remember { if (Build.VERSION.SDK_INT >= 33) LiquidShader() else null }
            if (backdrop != null && lens != null) {
                val panelLayer = rememberGraphicsLayer()
                val pos = remember { mutableStateOf(Offset.Zero) }
                val dark = c.dark
                this
                    .onGloballyPositioned { pos.value = it.positionInRoot() }
                    .clip(shape)
                    .drawWithContent {
                        val p = pos.value
                        // margin around the panel so the lens + diffusion sample real surroundings at the edges
                        val pad = (64f * density).toInt()
                        panelLayer.record(
                            size = IntSize(size.width.toInt() + 2 * pad, size.height.toInt() + 2 * pad)
                        ) {
                            translate(pad - p.x, pad - p.y) {
                                drawLayer(backdrop)
                                if (contentBackdrop != null) drawLayer(contentBackdrop)
                            }
                        }
                        val outline = shape.createOutline(size, layoutDirection, this)
                        val r = when (outline) {
                            is Outline.Rounded -> outline.roundRect.topLeftCornerRadius.x
                            is Outline.Rectangle -> 0f
                            else -> minOf(size.width, size.height) / 2f
                        }
                        val pf = pad.toFloat()
                        panelLayer.renderEffect = lens.effect(
                            pf, pf, pf + size.width, pf + size.height, r, density, strength, dark
                        )
                        translate(-pf, -pf) { drawLayer(panelLayer) }
                        drawContent()
                    }
            } else if (backdrop != null) {
                // Android 12 / 12L: no AGSL, so the lens is approximated with a few magnified bands near the
                // rim (content bends inward toward the edge), then diffused, saturated and lit.
                val panelLayer = rememberGraphicsLayer()
                val pos = remember { mutableStateOf(Offset.Zero) }
                val dark = c.dark
                this
                    .onGloballyPositioned { pos.value = it.positionInRoot() }
                    .clip(shape)
                    .drawWithContent {
                        val p = pos.value
                        val pad = (64f * density).toInt()
                        val pf = pad.toFloat()
                        val outline = shape.createOutline(size, layoutDirection, this)
                        val r = when (outline) {
                            is Outline.Rounded -> outline.roundRect.topLeftCornerRadius.x
                            is Outline.Rectangle -> 0f
                            else -> minOf(size.width, size.height) / 2f
                        }
                        val bezel = (10f + 16f * strength) * density
                        val step = 0.016f * (0.4f + strength)
                        val pw = size.width
                        val ph = size.height
                        val center = Offset(pf + pw / 2f, pf + ph / 2f)
                        panelLayer.record(
                            size = IntSize(size.width.toInt() + 2 * pad, size.height.toInt() + 2 * pad)
                        ) {
                            for (j in 0..4) {
                                val inset = j * bezel / 4f
                                val rr = androidx.compose.ui.geometry.RoundRect(
                                    pf + inset, pf + inset, pf + pw - inset, pf + ph - inset,
                                    androidx.compose.ui.geometry.CornerRadius((r - inset).coerceAtLeast(0f))
                                )
                                val path = androidx.compose.ui.graphics.Path().apply { addRoundRect(rr) }
                                val sc = 1f + step * (4 - j)
                                clipPath(path) {
                                    withTransform({
                                        scale(sc, sc, center)
                                        translate(pad - p.x, pad - p.y)
                                    }) {
                                        drawLayer(backdrop)
                                        if (contentBackdrop != null) drawLayer(contentBackdrop)
                                    }
                                }
                            }
                        }
                        val sat = RenderEffect.createColorFilterEffect(
                            android.graphics.ColorMatrixColorFilter(
                                android.graphics.ColorMatrix().apply { setSaturation(1f + 0.35f * strength) }
                            )
                        )
                        val sigma = (4f + 5f * (1f - strength)) * density
                        val blur = RenderEffect.createBlurEffect(sigma, sigma, Shader.TileMode.CLAMP)
                        panelLayer.renderEffect = RenderEffect.createChainEffect(sat, blur).asComposeRenderEffect()
                        translate(-pf, -pf) { drawLayer(panelLayer) }
                        // clear glass tint
                        drawRoundRect(
                            Color.White.copy(alpha = if (dark) 0.06f else 0.18f),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(r)
                        )
                        // soft inner glow on the lit (top-left) side
                        drawRoundRect(
                            brush = Brush.linearGradient(
                                listOf(Color.White.copy(alpha = 0.28f * (0.4f + strength)), Color.Transparent),
                                start = Offset.Zero, end = Offset(size.width * 0.65f, size.height * 0.65f)
                            ),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(r),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(bezel * 0.9f)
                        )
                        // thin specular rim: bright top-left, faint reflection bottom-right
                        drawRoundRect(
                            brush = Brush.linearGradient(
                                listOf(Color.White.copy(alpha = 0.9f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.38f)),
                                start = Offset.Zero, end = Offset(size.width, size.height)
                            ),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(r),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(1.6f * density)
                        )
                        drawContent()
                    }
            } else {
                this.clip(shape)
                    .background(
                        Brush.verticalGradient(
                            if (c.dark) listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.07f))
                            else listOf(Color.White.copy(alpha = 0.68f), Color.White.copy(alpha = 0.42f))
                        )
                    )
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(Color.White.copy(alpha = if (c.dark) 0.32f else 0.9f), Color.White.copy(alpha = 0.05f))
                        ),
                        shape
                    )
            }
        }
    }
}

/** Translucent surface used on top of the call screen's backdrop. */
fun Modifier.callGlass(shape: Shape): Modifier = composed {
    val dark = LocalColors.current.dark
    // Light app theme: the usual bright, white-translucent glass.
    // Dark app theme: a darker, more charcoal-toned glass, so the call screen matches the
    // moodier overall dark theme instead of looking like bright glary circles.
    val base = if (dark) Color(0xFF34363B) else Color.White
    val baseAlpha = if (dark) 0.5f else 0.20f
    this.clip(shape)
        .background(base.copy(alpha = baseAlpha))
        .border(
            1.dp,
            Brush.linearGradient(
                listOf(Color.White.copy(alpha = if (dark) 0.30f else 0.55f), Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = if (dark) 0.16f else 0.3f))
            ),
            shape
        )
}
